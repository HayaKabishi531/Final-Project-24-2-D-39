﻿//Preparing_Display_Data.cpp
/*
Filters data to create an annual cumulative energy chart by averaging over points on 
the Earth's surface when we pre-select, producing a CSV file for visualization using Energy_Scatter_plt.ipynb.
*/
#include "header.h"


// Map: day -> {lat, lon} -> vector of 24 energy values
unordered_map<int, unordered_map<string, vector<double>>> dailyEnergy;

// Function to safely compare floating-point values
bool isClose(double a, double b, double tol = 0.01) {
    return fabs(a - b) < tol;
}

// Function to process the CSV file
void processCSV(const std::string& inputFile) {
    ifstream file(inputFile);
    if (!file.is_open()) {
        cerr << "Error: Cannot open input file: " << inputFile << endl;
        return;
    }

    string line;
    getline(file, line); // Skip header

    while (getline(file, line)) {
        stringstream ss(line);
        string token;
        int timeDiff, localTime;
        double lat, lon, energy;

        getline(ss, token, ','); timeDiff = stoi(token);
        getline(ss, token, ','); localTime = stoi(token);
        getline(ss, token, ','); lat = stod(token);
        getline(ss, token, ','); lon = stod(token);
        getline(ss, token, ','); energy = stod(token);

        int day = (timeDiff / 1440) + 1;

        for (const auto& point : targetPoints) {
            if (isClose(lat, point.latitude) && isClose(lon, point.longitude)) {
                string key = to_string(point.latitude) + "," + to_string(point.longitude);

                if (dailyEnergy[day][key].size() < 24) {
                    dailyEnergy[day][key].resize(24, 0.0);
                }

                dailyEnergy[day][key][localTime] = energy;
            }
        }
    }
    file.close();
}


// Function to write the output file
void writeOutputCSV(const string& outputFile) {
    ofstream file(outputFile);
    if (!file.is_open()) {
        cerr << "Error: Cannot open output file: " << outputFile << endl;
        return;
    }

    file << "Day,Latitude,Longitude,EnergyAVG_Value\n";

    for (auto& dayData : dailyEnergy) {
        int day = dayData.first;
        for (const auto& point : targetPoints) {
            string key = to_string(point.latitude) + "," + to_string(point.longitude);

            if (dailyEnergy[day].find(key) == dailyEnergy[day].end()) {
                dailyEnergy[day][key] = vector<double>(24, 0.0);
            }

            double sumEnergy = accumulate(dailyEnergy[day][key].begin(), dailyEnergy[day][key].end(), 0.0);
            double avgEnergy = sumEnergy / 24.0;
            double finalEnergy = avgEnergy * point.area_m2;

            if (finalEnergy != 0) { // Skip writing zero-energy values
                file << day << "," << point.latitude << "," << point.longitude << ","
                    << fixed << setprecision(3) << finalEnergy << "\n";
            }
        }
    }
    file.close();
}


// Function: Prepare Display Data for a Given Year**
void preparing_display_data(const std::string& input_folder, const std::string& output_folder, int year) {
    std::cout << "Preparing Display Data for Year " << year << "..." << std::endl;

    std::string inputFile = input_folder + "\\Radiation_Energy_Absorption_" + std::to_string(year) + ".csv";
    std::string outputFile = output_folder + "\\Display_Radiation_Energy_Absorption_" + std::to_string(year) + ".csv";

    std::cout << "Processing input file: " << inputFile << std::endl;
    processCSV(inputFile);

    std::cout << "Writing output file: " << outputFile << std::endl;
    writeOutputCSV(outputFile);

    std::cout << "Display Data for " << year << " has been processed successfully.\n";
}

