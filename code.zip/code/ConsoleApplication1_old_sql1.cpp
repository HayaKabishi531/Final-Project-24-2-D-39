﻿// ConsoleApplication1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "Header.h"
#include <windows.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <sql.h>
//#include "Source1.cpp"

class ClimateData {
public:
	int station_id;
	double parameter;
	double pressure;
	double dew_point;
	int time;
};

class Jump_project
{
public:
	int jump_id_project;
	SQL_TIMESTAMP_STRUCT jump_project_date_created;
	SQLCHAR jump_project_name[256];
	SQLCHAR  jump_project_description[1096];
	SQLCHAR  jump_path_input_global[1096];
	SQLCHAR  jump_path_input_project[1096];
	SQLCHAR  jump_manage_code_global[1096];
	int jump_greed_large_distance;
	int jump_ngreed_small;
	int jump_jump_size_global;
	SQLCHAR jump_path_output_global[1096];
	SQLCHAR jump_path_output_image[1096];
	SQLCHAR jump_dataset[256];
	int jump_delta_time_in_data_global;
	int jump_min_distance_between_stations_global;
};

class Station
{
public:
	int staging_station_id;
	int staging_station_elevation;
	double staging_station_latitude;
	double staging_station_longitude;
};

class StationSelected
{
public:
	int staging_station_id_selected;
	int staging_station_elevation_selected;
	double staging_station_latitude_selected;
	double staging_station_longitude_selected;
};

class Coefficient
{
public:
	int coefficient_day_global;
	double coefficient_jump_size_global;
	int coefficient_wind_for_peaks_global;
	int coefficient_distance_thresh_for_jumps_global;
};

class Scheduler
{
public:
	int year;
	int month;
	int day;
	int id_project;
};

// Function to retrieve data and populate the class
std::vector<Scheduler> Get_Scheduler() {
	std::vector<Scheduler> data;

	cerr << "T0_1";

	//Initialize connection string 
	 // Get the current time
	std::time_t currentTime;
	std::time(&currentTime); // Get the current time

	std::tm localTime;
	localtime_s(&localTime, &currentTime); // Convert to local time
	
	cerr << "T0_2";


	// Extract the year, month, and day
	//int year = localTime.tm_year + 1900; // Years since 1900
	//int month = localTime.tm_mon + 1;    // Months are 0-indexed
	//int day = localTime.tm_mday;         // Day of the month


	// Create the connection string
	std::wstring connectionString = L"DRIVER={SQL Server};SERVER=10.78.5.14, 1433;DATABASE=Climate_Grid_Scheduler;Trusted=true;PWD=ASFD353fsdPPdsaeAEj904FD353;";

	cerr << "T0_3";

	std::wstring QueryString = L"SELECT [year] ,[month] ,[day], [id_project] FROM [Climate_Grid_Scheduler].[dbo].[scheduler_anomaly] WHERE [type] = 'entropy'";

	cerr << "T0_4";

	// Initialize variables
	SQLHENV henv = SQL_NULL_HENV;
	SQLHDBC hdbc = SQL_NULL_HDBC;
	SQLHSTMT hstmt = SQL_NULL_HSTMT;
	SQLRETURN ret;

	// Allocate environment handle
	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	ret = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_UINTEGER);

	cerr << "T0_5";

	// Allocate connection handle
	ret = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);

	// Connect to the database
	ret = SQLDriverConnect(hdbc, NULL, (SQLWCHAR*)connectionString.c_str(), SQL_NTS, NULL, 0, NULL, SQL_DRIVER_COMPLETE);

	// Allocate statement handle
	ret = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);

	// Execute the query
	ret = SQLExecDirect(hstmt, (SQLWCHAR*)QueryString.c_str(), SQL_NTS);

	cerr << "T0_6";

	// Fetch data and populate the vector of class instances
	while ((ret = SQLFetch(hstmt)) != SQL_NO_DATA) {
		Scheduler scheduler;
		ret = SQLGetData(hstmt, 1, SQL_C_LONG, &scheduler.year, sizeof(scheduler.year), NULL);
		ret = SQLGetData(hstmt, 2, SQL_C_LONG, &scheduler.month, sizeof(scheduler.month), NULL);
		ret = SQLGetData(hstmt, 3, SQL_C_LONG, &scheduler.day, sizeof(scheduler.day), NULL);
		ret = SQLGetData(hstmt, 4, SQL_C_LONG, &scheduler.id_project, sizeof(scheduler.id_project), NULL);
		data.push_back(scheduler);
	}

	cerr << "T0_7";

	// Clean up
	ret = SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
	ret = SQLDisconnect(hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_ENV, henv);

	cerr << "T0_8";

	return data;
}

std::vector<Jump_project> fetchDataFromDatabaseProjects(const std::wstring& id, int year) {
	std::vector<Jump_project> dataproject;

	//Initialize connection string 
	std::time_t currentTime;
	std::time(&currentTime); // Get the current time

	std::tm localTime;
	localtime_s(&localTime, &currentTime); // Convert to local time

	// Extract the year, month, and day
	//int year = localTime.tm_year + 1900; // Years since 1900
	int month = 12;// localTime.tm_mon + 1;    // Months are 0-indexed
	int day = 1;// localTime.tm_mday;         // Day of the month

	// Create the formatted string
	std::wstring formattedDate = std::to_wstring(year) + L"_" + (month < 10 ? L"0" : L"") + std::to_wstring(month);

	// Create the connection string
	std::wstring connectionString = L"DRIVER={SQL Server};SERVER=10.78.5.14, 1433;DATABASE=EcoVision_Climate_Parameter_Anomalies_" + formattedDate + L";Trusted=true;PWD=ASFD353fsdPPdsaeAEj904FD353;";
	std::wstring QueryString = L"SELECT [jump_id_project], [jump_project_date_created], [jump_project_name],[jump_project_description], [jump_path_input_global], [jump_path_input_project],[jump_manage_code_global], [jump_greed_large_distance], [jump_ngreed_small], [jump_jump_size_global], [jump_path_output_global], [jump_path_output_image], [jump_dataset], [jump_delta_time_in_data_global], [jump_min_distance_between_stations_global] FROM [dbo].[jump_project] WHERE [jump_id_project] =" + id + L"";

	// Initialize variables
	SQLHENV henv = SQL_NULL_HENV;
	SQLHDBC hdbc = SQL_NULL_HDBC;
	SQLHSTMT hstmt = SQL_NULL_HSTMT;
	SQLRETURN ret;

	// Allocate environment handle
	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	ret = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_UINTEGER);

	// Allocate connection handle
	ret = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);

	// Connect to the database
	ret = SQLDriverConnect(hdbc, NULL, (SQLWCHAR*)connectionString.c_str(), SQL_NTS, NULL, 0, NULL, SQL_DRIVER_COMPLETE);

	// Allocate statement handle
	ret = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);

	// Execute the query
	ret = SQLExecDirect(hstmt, (SQLWCHAR*)QueryString.c_str(), SQL_NTS);

	// Fetch data and populate the vector of class instances

	while ((ret = SQLFetch(hstmt)) != SQL_NO_DATA) {
		Jump_project jumpproject;

		ret = SQLGetData(hstmt, 1, SQL_C_LONG, &jumpproject.jump_id_project, sizeof(jumpproject.jump_id_project), NULL);
		ret = SQLGetData(hstmt, 2, SQL_C_TYPE_TIMESTAMP, &jumpproject.jump_project_date_created, sizeof(jumpproject.jump_project_date_created), NULL);
		ret = SQLGetData(hstmt, 3, SQL_C_CHAR, &jumpproject.jump_project_name, sizeof(jumpproject.jump_project_name), NULL);
		ret = SQLGetData(hstmt, 4, SQL_C_CHAR, &jumpproject.jump_project_description, sizeof(jumpproject.jump_project_description), NULL);
		ret = SQLGetData(hstmt, 5, SQL_C_CHAR, &jumpproject.jump_path_input_global, sizeof(jumpproject.jump_path_input_global), NULL);
		ret = SQLGetData(hstmt, 6, SQL_C_CHAR, &jumpproject.jump_path_input_project, sizeof(jumpproject.jump_path_input_project), NULL);
		ret = SQLGetData(hstmt, 7, SQL_C_CHAR, &jumpproject.jump_manage_code_global, sizeof(jumpproject.jump_manage_code_global), NULL);
		ret = SQLGetData(hstmt, 8, SQL_C_LONG, &jumpproject.jump_greed_large_distance, sizeof(jumpproject.jump_greed_large_distance), NULL);
		ret = SQLGetData(hstmt, 9, SQL_C_LONG, &jumpproject.jump_ngreed_small, sizeof(jumpproject.jump_ngreed_small), NULL);
		ret = SQLGetData(hstmt, 10, SQL_C_LONG, &jumpproject.jump_jump_size_global, sizeof(jumpproject.jump_jump_size_global), NULL);
		ret = SQLGetData(hstmt, 11, SQL_C_CHAR, &jumpproject.jump_path_output_global, sizeof(jumpproject.jump_path_output_global), NULL);
		ret = SQLGetData(hstmt, 12, SQL_C_CHAR, &jumpproject.jump_path_output_image, sizeof(jumpproject.jump_path_output_image), NULL);
		ret = SQLGetData(hstmt, 13, SQL_C_CHAR, &jumpproject.jump_dataset, sizeof(jumpproject.jump_dataset), NULL);
		ret = SQLGetData(hstmt, 14, SQL_C_LONG, &jumpproject.jump_delta_time_in_data_global, sizeof(jumpproject.jump_delta_time_in_data_global), NULL);
		ret = SQLGetData(hstmt, 15, SQL_C_LONG, &jumpproject.jump_min_distance_between_stations_global, sizeof(jumpproject.jump_min_distance_between_stations_global), NULL);

		dataproject.push_back(jumpproject);
	}

	// Clean up
	ret = SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
	ret = SQLDisconnect(hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_ENV, henv);

	return dataproject;
}

std::vector<ClimateData> fetchDataFromDatabase(const std::wstring& id, int year, int month, int day) {
	std::vector<ClimateData> data;

	//Initialize connection string 
	 // Get the current time
	std::time_t currentTime;
	std::time(&currentTime); // Get the current time

	std::tm localTime;
	localtime_s(&localTime, &currentTime); // Convert to local time

	// Extract the year, month, and day
	//int year = localTime.tm_year + 1900; // Years since 1900
	//int month = localTime.tm_mon + 1;    // Months are 0-indexed
	//int day = localTime.tm_mday;         // Day of the month

	// Create the formatted string
	std::wstring formattedDate = std::to_wstring(year) + L"_" + (month < 10 ? L"0" : L"") + std::to_wstring(month) + L"_" + (day < 10 ? L"0" : L"") + std::to_wstring(day);

	// Create the connection string
	std::wstring connectionString = L"DRIVER={SQL Server};SERVER=10.78.5.14, 1433;DATABASE=EcoVision_Climate_Grid_Era5_" + formattedDate + L";Trusted=true;PWD=ASFD353fsdPPdsaeAEj904FD353;";

	std::wstring QueryString = L"SELECT [station_id] ,ROUND([era5_meteodata_temperature], 2) AS [parameter] ,[era5_meteodata_pressure] AS [pressure] ,[era5_meteodata_dew_point] AS [dew_point],DATEDIFF(MINUTE, '2000-01-01 00:00:00.000', [utc_datetime]) AS [time] FROM [dbo].[era5_meteodata] A INNER JOIN (SELECT [station_id],CAST([latitude] AS DECIMAL(38, 10)) AS [latitude],CAST([longitude] AS DECIMAL(38, 10)) AS [longitude] FROM [EcoVision_Climate_Parameter_Anomalies_2024_12].[dbo].[era5_station]) B ON CAST(A.[latitude] AS DECIMAL(38, 10)) = CAST(B.[latitude] AS DECIMAL(38, 10)) AND CAST(A.[longitude] AS DECIMAL(38, 10)) = CAST(B.[longitude] AS DECIMAL(38, 10))";

	// Initialize variables
	SQLHENV henv = SQL_NULL_HENV;
	SQLHDBC hdbc = SQL_NULL_HDBC;
	SQLHSTMT hstmt = SQL_NULL_HSTMT;
	SQLRETURN ret;

	// Allocate environment handle
	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	ret = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_UINTEGER);

	// Allocate connection handle
	ret = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);

	// Connect to the database
	ret = SQLDriverConnect(hdbc, NULL, (SQLWCHAR*)connectionString.c_str(), SQL_NTS, NULL, 0, NULL, SQL_DRIVER_COMPLETE);

	// Allocate statement handle
	ret = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);

	// Execute the query
	ret = SQLExecDirect(hstmt, (SQLWCHAR*)QueryString.c_str(), SQL_NTS);

	// Fetch data and populate the vector of class instances
	while ((ret = SQLFetch(hstmt)) != SQL_NO_DATA) {
		ClimateData climateData;
		ret = SQLGetData(hstmt, 1, SQL_C_LONG, &climateData.station_id, sizeof(climateData.station_id), NULL);
		ret = SQLGetData(hstmt, 2, SQL_C_DOUBLE, &climateData.parameter, sizeof(climateData.parameter), NULL);
		ret = SQLGetData(hstmt, 3, SQL_C_DOUBLE, &climateData.pressure, sizeof(climateData.pressure), NULL);
		ret = SQLGetData(hstmt, 4, SQL_C_DOUBLE, &climateData.dew_point, sizeof(climateData.dew_point), NULL);
		ret = SQLGetData(hstmt, 5, SQL_C_LONG, &climateData.time, sizeof(climateData.time), NULL);
		data.push_back(climateData);
	}

	// Clean up
	ret = SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
	ret = SQLDisconnect(hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_ENV, henv);

	return data;
}

std::vector<ClimateData> fetchDataFromDatabaseFill(const std::wstring& id, int year, int month, int day) {
	std::vector<ClimateData> data;

	//Initialize connection string 
	 // Get the current time
	std::time_t currentTime;
	std::time(&currentTime); // Get the current time

	std::tm localTime;
	localtime_s(&localTime, &currentTime); // Convert to local time

	// Extract the year, month, and day
	//int year = localTime.tm_year + 1900; // Years since 1900
	//int month = 12;//localTime.tm_mon + 1;    // Months are 0-indexed
	//int day = 1;// localTime.tm_mday;         // Day of the month

	// Create the formatted string
	std::wstring formattedDate = std::to_wstring(year) + L"_" + (month < 10 ? L"0" : L"") + std::to_wstring(month);

	// Create the connection string
	std::wstring connectionString = L"DRIVER={SQL Server};SERVER=10.78.5.14, 1433;DATABASE=EcoVision_Climate_Parameter_Anomalies_" + formattedDate + L";Trusted=true;PWD=ASFD353fsdPPdsaeAEj904FD353;";

	std::wstring QueryString = L"SELECT [station_id], ROUND([parameter],2) AS [parameter], [time] FROM [EcoVision_Climate_Parameter_Anomalies_" + formattedDate + L"].[dbo].[era5_data_temperature] WHERE [id_project] = " + id + L"";

	// Initialize variables
	SQLHENV henv = SQL_NULL_HENV;
	SQLHDBC hdbc = SQL_NULL_HDBC;
	SQLHSTMT hstmt = SQL_NULL_HSTMT;
	SQLRETURN ret;

	// Allocate environment handle
	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	ret = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_UINTEGER);

	// Allocate connection handle
	ret = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);

	// Connect to the database
	ret = SQLDriverConnect(hdbc, NULL, (SQLWCHAR*)connectionString.c_str(), SQL_NTS, NULL, 0, NULL, SQL_DRIVER_COMPLETE);

	// Allocate statement handle
	ret = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);

	// Execute the query
	ret = SQLExecDirect(hstmt, (SQLWCHAR*)QueryString.c_str(), SQL_NTS);

	// Fetch data and populate the vector of class instances
	while ((ret = SQLFetch(hstmt)) != SQL_NO_DATA) {
		ClimateData climateData;
		ret = SQLGetData(hstmt, 1, SQL_C_LONG, &climateData.station_id, sizeof(climateData.station_id), NULL);
		ret = SQLGetData(hstmt, 2, SQL_C_DOUBLE, &climateData.parameter, sizeof(climateData.parameter), NULL);
		ret = SQLGetData(hstmt, 3, SQL_C_LONG, &climateData.time, sizeof(climateData.time), NULL);
		data.push_back(climateData);
	}

	// Clean up
	ret = SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
	ret = SQLDisconnect(hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_ENV, henv);

	return data;
}

std::vector<Station> fetchDataFromDatabaseStation(int year) {
	std::vector<Station> data;

	//Initialize connection string 
	 // Get the current time
	std::time_t currentTime;
	std::time(&currentTime); // Get the current time

	std::tm localTime;
	localtime_s(&localTime, &currentTime); // Convert to local time

	// Extract the year, month, and day
	//int year = localTime.tm_year + 1900; // Years since 1900
	int month = 12;//localTime.tm_mon + 1;    // Months are 0-indexed
	int day = 1;//localTime.tm_mday;         // Day of the month

	// Create the formatted string
	std::wstring formattedDate = std::to_wstring(year) + L"_" + (month < 10 ? L"0" : L"") + std::to_wstring(month);

	// Create the connection string
	std::wstring connectionString = L"DRIVER={SQL Server};SERVER=10.78.5.14, 1433;DATABASE=EcoVision_Climate_Parameter_Anomalies_" + formattedDate + L";Trusted=true;PWD=ASFD353fsdPPdsaeAEj904FD353;";

	std::wstring QueryString = L"SELECT [station_id],0 AS [elevation] ,[latitude],[longitude] FROM [dbo].[era5_station]";

	// Initialize variables
	SQLHENV henv = SQL_NULL_HENV;
	SQLHDBC hdbc = SQL_NULL_HDBC;
	SQLHSTMT hstmt = SQL_NULL_HSTMT;
	SQLRETURN ret;

	// Allocate environment handle
	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	ret = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_UINTEGER);

	// Allocate connection handle
	ret = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);

	// Connect to the database
	ret = SQLDriverConnect(hdbc, NULL, (SQLWCHAR*)connectionString.c_str(), SQL_NTS, NULL, 0, NULL, SQL_DRIVER_COMPLETE);

	// Allocate statement handle
	ret = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);

	// Execute the query
	ret = SQLExecDirect(hstmt, (SQLWCHAR*)QueryString.c_str(), SQL_NTS);

	// Fetch data and populate the vector of class instances
	while ((ret = SQLFetch(hstmt)) != SQL_NO_DATA) {
		Station stationData;
		ret = SQLGetData(hstmt, 1, SQL_C_LONG, &stationData.staging_station_id, sizeof(stationData.staging_station_id), NULL);
		ret = SQLGetData(hstmt, 2, SQL_C_LONG, &stationData.staging_station_elevation, sizeof(stationData.staging_station_elevation), NULL);
		ret = SQLGetData(hstmt, 3, SQL_C_DOUBLE, &stationData.staging_station_latitude, sizeof(stationData.staging_station_latitude), NULL);
		ret = SQLGetData(hstmt, 4, SQL_C_DOUBLE, &stationData.staging_station_longitude, sizeof(stationData.staging_station_longitude), NULL);
		data.push_back(stationData);
	}

	// Clean up
	ret = SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
	ret = SQLDisconnect(hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_ENV, henv);

	return data;
}

std::vector<StationSelected> fetchDataFromDatabaseStationSelected(int year) {
	std::vector<StationSelected> data;

	//Initialize connection string 
	 // Get the current time
	std::time_t currentTime;
	std::time(&currentTime); // Get the current time

	std::tm localTime;
	localtime_s(&localTime, &currentTime); // Convert to local time

	// Extract the year, month, and day
	//int year = localTime.tm_year + 1900; // Years since 1900
	int month = 12;// localTime.tm_mon + 1;    // Months are 0-indexed
	int day = 1;// localTime.tm_mday;         // Day of the month

	// Create the formatted string
	std::wstring formattedDate = std::to_wstring(year) + L"_" + (month < 10 ? L"0" : L"") + std::to_wstring(month);

	// Create the connection string
	std::wstring connectionString = L"DRIVER={SQL Server};SERVER=10.78.5.14, 1433;DATABASE=EcoVision_Climate_Parameter_Anomalies_" + formattedDate + L";Trusted=true;PWD=ASFD353fsdPPdsaeAEj904FD353;";

	std::wstring QueryString = L"SELECT [station_id],0 AS [elevation] ,[latitude],[longitude] FROM [dbo].[era5_station]";

	// Initialize variables
	SQLHENV henv = SQL_NULL_HENV;
	SQLHDBC hdbc = SQL_NULL_HDBC;
	SQLHSTMT hstmt = SQL_NULL_HSTMT;
	SQLRETURN ret;

	// Allocate environment handle
	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	ret = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_UINTEGER);

	// Allocate connection handle
	ret = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);

	// Connect to the database
	ret = SQLDriverConnect(hdbc, NULL, (SQLWCHAR*)connectionString.c_str(), SQL_NTS, NULL, 0, NULL, SQL_DRIVER_COMPLETE);

	// Allocate statement handle
	ret = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);

	// Execute the query
	ret = SQLExecDirect(hstmt, (SQLWCHAR*)QueryString.c_str(), SQL_NTS);

	// Fetch data and populate the vector of class instances
	while ((ret = SQLFetch(hstmt)) != SQL_NO_DATA) {
		StationSelected stationSelected;
		ret = SQLGetData(hstmt, 1, SQL_C_LONG, &stationSelected.staging_station_id_selected, sizeof(stationSelected.staging_station_id_selected), NULL);
		ret = SQLGetData(hstmt, 2, SQL_C_LONG, &stationSelected.staging_station_elevation_selected, sizeof(stationSelected.staging_station_elevation_selected), NULL);
		ret = SQLGetData(hstmt, 3, SQL_C_DOUBLE, &stationSelected.staging_station_latitude_selected, sizeof(stationSelected.staging_station_latitude_selected), NULL);
		ret = SQLGetData(hstmt, 4, SQL_C_DOUBLE, &stationSelected.staging_station_longitude_selected, sizeof(stationSelected.staging_station_longitude_selected), NULL);
		data.push_back(stationSelected);
	}

	// Clean up
	ret = SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
	ret = SQLDisconnect(hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_ENV, henv);

	return data;
}

std::vector<Coefficient> fetchDataFromDatabaseCoefficient(const std::wstring& id, int year, int month, int day) {
	std::vector<Coefficient> data;

	//Initialize connection string 
	 // Get the current time
	std::time_t currentTime;
	std::time(&currentTime); // Get the current time

	std::tm localTime;
	localtime_s(&localTime, &currentTime); // Convert to local time

	// Extract the year, month, and day
	//int year = localTime.tm_year + 1900; // Years since 1900
	//int month = localTime.tm_mon + 1;    // Months are 0-indexed
	//int day = localTime.tm_mday;         // Day of the month

	// Create the formatted string
	std::wstring formattedDate = std::to_wstring(year) + L"_" + (month < 10 ? L"0" : L"") + std::to_wstring(month);

	// Create the connection string
	std::wstring connectionString = L"DRIVER={SQL Server};SERVER=10.78.5.14, 1433;DATABASE=EcoVision_Climate_Parameter_Anomalies_" + formattedDate + L";Trusted=true;PWD=ASFD353fsdPPdsaeAEj904FD353;";

	std::wstring QueryString = L"SELECT [coefficient_day_global],[coefficient_jump_size_global],[coefficient_distance_thresh_for_jumps_global],[coefficient_wind_for_peaks_global] FROM [dbo].[jump_coefficient] WHERE [jump_id_project] =" + id + L"";

	// Initialize variables
	SQLHENV henv = SQL_NULL_HENV;
	SQLHDBC hdbc = SQL_NULL_HDBC;
	SQLHSTMT hstmt = SQL_NULL_HSTMT;
	SQLRETURN ret;

	// Allocate environment handle
	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	ret = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_UINTEGER);

	// Allocate connection handle
	ret = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);

	// Connect to the database
	ret = SQLDriverConnect(hdbc, NULL, (SQLWCHAR*)connectionString.c_str(), SQL_NTS, NULL, 0, NULL, SQL_DRIVER_COMPLETE);

	// Allocate statement handle
	ret = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);

	// Execute the query
	ret = SQLExecDirect(hstmt, (SQLWCHAR*)QueryString.c_str(), SQL_NTS);

	// Fetch data and populate the vector of class instances
	while ((ret = SQLFetch(hstmt)) != SQL_NO_DATA) {
		Coefficient coefficient_jump;
		ret = SQLGetData(hstmt, 1, SQL_C_LONG, &coefficient_jump.coefficient_day_global, sizeof(coefficient_jump.coefficient_day_global), NULL);
		ret = SQLGetData(hstmt, 2, SQL_C_DOUBLE, &coefficient_jump.coefficient_jump_size_global, sizeof(coefficient_jump.coefficient_jump_size_global), NULL);
		ret = SQLGetData(hstmt, 3, SQL_C_LONG, &coefficient_jump.coefficient_distance_thresh_for_jumps_global, sizeof(coefficient_jump.coefficient_distance_thresh_for_jumps_global), NULL);
		ret = SQLGetData(hstmt, 4, SQL_C_LONG, &coefficient_jump.coefficient_wind_for_peaks_global, sizeof(coefficient_jump.coefficient_wind_for_peaks_global), NULL);
		data.push_back(coefficient_jump);
	}

	// Clean up
	ret = SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
	ret = SQLDisconnect(hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_ENV, henv);

	return data;
}

int main()//int argc, wchar_t* argv[])
{
	//Here inser new function select oreder of run for today

	cerr << "T0";
	std::vector<Scheduler> scheduler = Get_Scheduler();

	int i, j;

	cerr << "T1";

	//Folder
	// Get the current time
	std::time_t currentTime;
	std::time(&currentTime); // Get the current time

	std::tm localTime;
	localtime_s(&localTime, &currentTime); // Convert to local time

	// Extract the year, month, and day
	int year = scheduler[0].year;   // localTime.tm_year + 1900; // Years since 1900
	int month = scheduler[0].month; // localTime.tm_mon + 1;    // Months are 0-indexed
	int day = scheduler[0].day;     //localTime.tm_mday;         // Day of the month
	std::wstring id = std::to_wstring(scheduler[0].id_project);//std::to_wstring(26); //scheduler[0].id_project

	// Create the formatted string
	std::string formattedDate = std::to_string(year) + "_" + (month < 10 ? "0" : "") + std::to_string(month) + "_" + (day < 10 ? "0" : "") + std::to_string(day);


	Clim cc1;
	cc1.CSVfile_vertical_glob = 1;


	//Define configuration plan

	std::vector<Jump_project> fetchProject = fetchDataFromDatabaseProjects(id, year);

	cc1.MakeGreed1_help_glob = 1;

	//	cc1.Path1_Input_glob = reinterpret_cast<const char*>(fetchProject[0].jump_path_input_global);

	//	cc1.Path2_Input_glob = std::string(reinterpret_cast<const char*>(fetchProject[0].jump_path_input_project)) + std::string(reinterpret_cast<const char*>(fetchProject[0].jump_project_name)) + "\\" + formattedDate + "\\";

	//	cc1.Path1_Output_glob = std::string(reinterpret_cast<const char*>(fetchProject[0].jump_path_output_global)) + std::string(reinterpret_cast<const char*>(fetchProject[0].jump_project_name)) + "\\" + formattedDate + "\\result\\";

	//	cc1.Path1_Output_clust_glob = std::string(reinterpret_cast<const char*>(fetchProject[0].jump_path_output_global)) + std::string(reinterpret_cast<const char*>(fetchProject[0].jump_project_name)) + "\\" + formattedDate + "\\cluster\\";

	//	cc1.Path1_Output_pict1_glob = std::string(reinterpret_cast<const char*>(fetchProject[0].jump_path_output_image)) + std::string(reinterpret_cast<const char*>(fetchProject[0].jump_project_name)) + "\\" + formattedDate + "\\image\\";

	cerr << "T2";

	cc1.ManageCode_glob = reinterpret_cast<const char*>(fetchProject[0].jump_manage_code_global);

	cc1.GreedLarge1dist1_Glob = fetchProject[0].jump_greed_large_distance;
	cc1.NgreedSmall1_Glob = fetchProject[0].jump_ngreed_small;
	cc1.JumpSzGlob = fetchProject[0].jump_jump_size_global;
	cc1.DeltaTimeInDataGlob = fetchProject[0].jump_delta_time_in_data_global;
	cc1.PointsInDayGlob = 1440 / cc1.DeltaTimeInDataGlob;
	cc1.MinDistBetweenStationsGlob = fetchProject[0].jump_min_distance_between_stations_global;

	cc1.JumpDownYes_Glob = 1;
	cc1.JumpUpYes_Glob = 1;
	cc1.MakeClustersJumps_Glob = 0;
	cc1.MakePictures_Glob = 0;
	cc1.distThreshforClust1_glob = 300000;
	//	cc1.TreshClust2_glob = 4;
	cc1.MinDistNewBorn_glob = 1000000;
	cc1.Stat_select_glob = 0;
	cc1.SaveLargeFiles_glob = 1;

	//Call data
	//std::vector<ClimateData> fetchedData = fetchDataFromDatabase(id, year, month, day);
	//add data
	//std::vector<ClimateData> fetchedData1 = fetchDataFromDatabaseFill(id, 2024, month, day);


	cc1.consol = 1;

	std::vector<Station> stations = fetchDataFromDatabaseStation(year);

	std::vector<StationSelected> station_selected = fetchDataFromDatabaseStationSelected(year);

	//Station and station select 
	Stat1 st;
	st.elevation = 0;
	st.id_count = -1;
	st.model = -1;
	st.lon = 0.001;
	st.lat = 0.001;
	st.last = 0;
	st.index = -1;
	st.flag = -1;

	cc1.Stat1_glob.push_back(st);
	for (size_t i = 0; i < stations.size(); ++i) //*
	{
		if (stations[i].staging_station_id < 0) continue;
		if (stations[i].staging_station_id >= cc1.Stat1_glob.size())
			for (j = cc1.Stat1_glob.size(); j <= stations[i].staging_station_id; j++)
				cc1.Stat1_glob.push_back(st);

		cc1.Stat1_glob[stations[i].staging_station_id].elevation = stations[i].staging_station_elevation;
		cc1.Stat1_glob[stations[i].staging_station_id].lat = stations[i].staging_station_latitude;
		cc1.Stat1_glob[stations[i].staging_station_id].lon = stations[i].staging_station_longitude;
		cc1.Stat1_glob[stations[i].staging_station_id].model = 0;
	}
	//cc1.ReadSelect1(cc1.Path2_Input_glob);

	for (size_t i = 0; i < station_selected.size(); ++i) //selected
		if (station_selected[i].staging_station_id_selected >= 0 && station_selected[i].staging_station_id_selected < cc1.Stat1_glob.size())
			cc1.select1_glob.push_back(station_selected[i].staging_station_id_selected);

	for (i = 0; i < cc1.select1_glob.size(); i++)
		cc1.Stat1_glob[cc1.select1_glob[i]].index = i;

	ofstream fout;
	fout.open(cc1.Path1_Output_glob + "stat_c", ios::out);
	for (i = 0; i < cc1.select1_glob.size(); i++)
		fout << cc1.select1_glob[i] << " " << cc1.Stat1_glob[cc1.select1_glob[i]].elevation << " " << cc1.Stat1_glob[cc1.select1_glob[i]].lat
		<< " " << cc1.Stat1_glob[cc1.select1_glob[i]].lon << "\n";
	fout.close();

	//Interval calculate
	/*cc1.Stat_select_glob = 1;
	cc1.Path2_Input_glob = "G:\\EcoVision\\EcoVision_Climate_Parameter_Anomalies\\Data\\Output\\era5_meteodata_temperature_MAX\\";
	cc1.Path1_Output_glob = cc1.Path2_Input_glob;
	cc1.ReadSelect1(cc1.Path2_Input_glob);
	cc1.Sdvig_calc1(cc1.Path2_Input_glob);
	return 0;*/

	string fname = cc1.Path1_Output_glob + "station_entrop.csv";
	fout.open(fname.c_str(), ios::out);
	if (!fout.good()) cc1.error(fname.c_str());

	fout << "station_id,latitude,longitude";
	for (i = 0; i < cc1.Stat1_glob.size(); i++)
		if (cc1.Stat1_glob[i].index != -1)
			fout << "\n" << i << "," << cc1.Stat1_glob[i].lat << "," << cc1.Stat1_glob[i].lon;

	fout.close();

	cc1.MakeGreed1_help_glob = 0;
	cc1.MakeGreed1();

	cc1.NtMax_glob = 24;
	int Nst = cc1.select1_glob.size();
	int Nt = cc1.NtMax_glob;
	cc1.tmp1 = new short* [Nst];
	cc1.prs1d = new double* [Nst];
	cc1.hmd1 = new short* [Nst];
	cc1.hmdAbs1 = new double* [Nst];

	cc1.Data_entropy1_mas1_glob.reserve(Nst * Nt);

	for (j = 0; j < Nst; j++)
	{
		cc1.tmp1[j] = new short[Nt];
		cc1.prs1d[j] = new double[Nt];
		cc1.hmd1[j] = new short[Nt];
		cc1.hmdAbs1[j] = new double[Nt];
	}

	//Call data
	std::vector<ClimateData> fetchedData;
	fetchedData.reserve(Nst * Nt);

	Data_entropy1 de1;

	cc1.year1_glob = year;
	cc1.month1_glob = month;
	cc1.day1_glob = day;

	int year0 = cc1.year1_glob;
	int month0 = cc1.month1_glob;
	int day0 = cc1.day1_glob;

	std::string str(id.begin(), id.end());
	std::cout << str << std::endl;

	char buf[1000];
	for (i = 1; i <= 3; i++)
	{
		sprintf_s(buf, "data_entrop_%i", i);
		fname = cc1.Path1_Output_glob + buf;
		fout.clear();
		fout.open(fname, ios::out);
		int k = 0;

		cc1.Data_entropy1_mas1_glob.clear();
		fetchedData.clear();
		fetchedData = fetchDataFromDatabase(id, cc1.year1_glob, cc1.month1_glob, cc1.day1_glob);
		for (const auto& data1 : fetchedData)
		{
			if (data1.station_id < 0 || data1.station_id >= cc1.Stat1_glob.size()) continue;

			if (data1.parameter == 10000 || data1.time == 10000) continue;

			de1.time = data1.time;
			de1.temp = data1.parameter;
			de1.pressure = data1.pressure;
			de1.dew_point = data1.dew_point;
			de1.stat = data1.station_id;

			cc1.Data_entropy1_mas1_glob.push_back(de1);
			fout << "\n" << k << " " << data1.time << " " << data1.station_id << " " << data1.parameter
				<< " " << data1.parameter << " " << data1.parameter << "\n";
			k++;
		}

		fout.close();
		cc1.DateProceed2(year0, month0, day0, i);
		cc1.Entropy1_Anal1_SQL_cyc(cc1.year1_glob, cc1.month1_glob, cc1.day1_glob);
	}

	
	cc1.ReadData_entropy1_greed_SQL();

}
