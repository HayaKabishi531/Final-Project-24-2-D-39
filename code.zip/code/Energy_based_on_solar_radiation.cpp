﻿//Energy_based_on_solar_radiation.cpp
/*
Calculates energy absorption using radiation and albedo formulas, 
and produces an annual CSV output with energy values ​​for each point and time.
*/
#include "header.h"



std::mutex output_mutex;

// Function to compute declination angle
inline double calculate_declination_angle(int day_of_year) {
    return 23.45 * sin((360.0 / 365.0) * (day_of_year + 284) * DEG_TO_RAD);
}

// Function to compute hour angle
inline double calculate_hour_angle(double local_time) {
    return (local_time - 12.0) * 15.0;
}

// Function to compute solar zenith angle
inline double calculate_zenith_angle(double latitude, double declination, double hour_angle) {
    return acos(sin(latitude * DEG_TO_RAD) * sin(declination * DEG_TO_RAD) +
        cos(latitude * DEG_TO_RAD) * cos(declination * DEG_TO_RAD) * cos(hour_angle * DEG_TO_RAD));
}

// **Read CSV data into an unordered_map**
void read_csv(const std::string& file_path,
    std::unordered_map<std::tuple<double, double, double>, DataEntry, TupleHash>& data_map,
    std::set<std::tuple<double, double, double>>& all_keys) {
    // Function code remains unchanged


    std::ifstream file(file_path);
    if (!file.is_open()) {
        std::cerr << "Error: Cannot open file: " << file_path << std::endl;
        return;
    }

    std::string line;
    std::getline(file, line); // Skip header

    while (std::getline(file, line)) {
        std::istringstream ss(line);
        double time_difference, latitude, longitude;
        DataEntry entry;
        char comma;

        if (!(ss >> time_difference >> comma >> entry.value >> comma >> latitude >> comma >> longitude)) {
            continue; // Skip invalid lines
        }

        std::tuple<double, double, double> key = { time_difference, latitude, longitude };
        data_map[key] = entry;
        all_keys.insert(key);
    }
}

// Process only common keys
void process_data(
    const std::unordered_map<std::tuple<double, double, double>, DataEntry, TupleHash>& olr_data,
    const std::unordered_map<std::tuple<double, double, double>, DataEntry, TupleHash>& str_data,
    const std::unordered_map<std::tuple<double, double, double>, DataEntry, TupleHash>& ssrd_data,
    const std::unordered_map<std::tuple<double, double, double>, DataEntry, TupleHash>& tcc_data,
    const std::unordered_map<std::tuple<double, double, double>, DataEntry, TupleHash>& albedo_data,
    const std::set<std::tuple<double, double, double>>& all_keys,
    std::ofstream& out) {

    std::vector<std::tuple<double, double, double>> sorted_keys(all_keys.begin(), all_keys.end()); // Sort once
    std::sort(sorted_keys.begin(), sorted_keys.end()); // Ensures processing in order

    for (const auto& key : sorted_keys) {
        if (olr_data.count(key) && str_data.count(key) && ssrd_data.count(key) && tcc_data.count(key) && albedo_data.count(key)) {
            auto& olr_entry = olr_data.at(key);
            auto& str_entry = str_data.at(key);
            auto& ssrd_entry = ssrd_data.at(key);
            auto& tcc_entry = tcc_data.at(key);
            auto& albedo_entry = albedo_data.at(key);

            double time_difference = std::get<0>(key);
            double latitude = std::get<1>(key);
            double longitude = std::get<2>(key);

            int day_of_year = static_cast<int>(std::floor(time_difference / 1440.0)) + 1;
            double local_time = fmod(time_difference / MINUTES_IN_HOUR, HOURS_IN_DAY);
            double declination = calculate_declination_angle(day_of_year);
            double hour_angle = calculate_hour_angle(local_time);
            double zenith_angle = calculate_zenith_angle(latitude, declination, hour_angle);

            double corrected_ssrd = std::max(0.0, ssrd_entry.value) * cos(zenith_angle);
            double corrected_albedo = std::clamp(albedo_entry.value, 0.2, 0.7);
            double corrected_str = std::abs(str_entry.value);

            if (zenith_angle > 90.0) {
                corrected_ssrd = 0.0;
            }

            double energy = (corrected_str - olr_entry.value) +
                (corrected_ssrd * (1.0 - corrected_albedo) * (tcc_entry.value - 1.0));

            std::lock_guard<std::mutex> lock(output_mutex);
            out << time_difference << "," << local_time << "," << latitude << ","
                << longitude << "," << energy << "\n";
        }
    }
}

//Process Energy Radiation Data (for a Specific Year)**
void process_energy_radiation(const std::string& input_folder, const std::string& output_folder, int year){
    std::cout << "Processing Energy Calculation (Solar Radiation) for " << year << "..." << std::endl;

    std::unordered_map<std::tuple<double, double, double>, DataEntry, TupleHash> olr_data, str_data, ssrd_data, tcc_data, albedo_data;
    std::set<std::tuple<double, double, double>> all_keys;

    // **Load data**
    read_csv(input_folder + "\\OLR_" + std::to_string(year) + ".csv", olr_data, all_keys);
    read_csv(input_folder + "\\STR_" + std::to_string(year) + ".csv", str_data, all_keys);
    read_csv(input_folder + "\\SSRD_" + std::to_string(year) + ".csv", ssrd_data, all_keys);
    read_csv(input_folder + "\\TCC_" + std::to_string(year) + ".csv", tcc_data, all_keys);
    read_csv(input_folder + "\\FA_" + std::to_string(year) + ".csv", albedo_data, all_keys);

    std::string output_file = output_folder + "\Radiation_Energy_Absorption_" + std::to_string(year) + ".csv";
    std::ofstream out(output_file);
    if (!out.is_open()) {
        std::cerr << "Error opening output file: " << output_file << std::endl;
        return;
    }

    out << "Time_difference,Local_Time,Latitude,Longitude,Energy_Value\n";
    process_data(olr_data, str_data, ssrd_data, tcc_data, albedo_data, all_keys, out);
    out.close();

    std::cout << "Energy calculations completed. Output saved to: " << output_file << std::endl;
}

