﻿// Level.cpp
/*
Divides the Earth's data points into latitude-based levels
and calculates representative grid areas for energy absorption estimates based on the Earth's spherical shape.
*/
#include "header.h"


// Function to calculate the great-circle distance between two points
inline long double calcGPSDistance(long double latitude_new, long double longitude_new, long double latitude_old, long double longitude_old) {
    // Convert degrees to radians
    long double lat_new_rad = latitude_new * DEG_TO_RAD;
    long double lat_old_rad = latitude_old * DEG_TO_RAD;
    long double lat_diff_rad = (latitude_new - latitude_old) * DEG_TO_RAD;
    long double lng_diff_rad = (longitude_new - longitude_old) * DEG_TO_RAD;

    // Apply the haversine formula
    long double a = sin(lat_diff_rad / 2) * sin(lat_diff_rad / 2) +
        cos(lat_new_rad) * cos(lat_old_rad) *
        sin(lng_diff_rad / 2) * sin(lng_diff_rad / 2);
    long double c = 2 * atan2(sqrt(a), sqrt(1 - a));

    return EARTH_RADIUS * c; // Distance in kilometers
}

// Function to process the level area calculation
void process_level_area(const std::string& input_directory, const std::string& output_file, const std::string& input_filename) {
    std::cout << "Starting Level Area Calculation for file: " << input_filename << std::endl;
    // Input file path
    std::string input_file = input_directory + input_filename;

    // Open the input file
    std::ifstream infile(input_file);
    if (!infile.is_open()) {
        std::cerr << "Failed to open input file: " << input_file << std::endl;
        return;
    }

    // Skip the header
    std::string line;
    std::getline(infile, line);

    // Data structures
    std::set<std::pair<long double, long double>> processed_levels; // To track processed levels
    std::map<std::pair<long double, long double>, long double> level_areas; // Store area per level

    // Read input data
    while (std::getline(infile, line)) {
        std::stringstream ss(line);
        std::string token;
        std::vector<std::string> row;

        while (std::getline(ss, token, ',')) {
            row.push_back(token);
        }

        // Extract lat_start and lat_end for levels
        long double lat_start = std::stold(row[4]);
        long double lat_end = std::stold(row[5]);

        // Consider only positive latitudes
        if (lat_start < 0) {
            continue;
        }

        // If level already processed, skip it
        std::pair<long double, long double> level = { lat_start, lat_end };
        if (processed_levels.find(level) != processed_levels.end()) {
            continue;
        }

        // Calculate area for the first occurrence of this level
        long double height = calcGPSDistance(lat_start, 0, lat_end, 0);
        long double mid_lat = (lat_start + lat_end) / 2.0;
        long double width = calcGPSDistance(mid_lat, 0, mid_lat, 10.0); // 10° longitude difference
        long double area = height * width;

        // Save area and mark the level as processed
        level_areas[level] = area;
        processed_levels.insert(level);
    }
    infile.close();

    // Write output to CSV
    std::ofstream outfile(output_file);
    if (!outfile.is_open()) {
        std::cerr << "Failed to open output file: " << output_file << std::endl;
        return;
    }

    // Write header
    outfile << "start_latitude,end_latitude,Area (km^2)" << std::endl;

    // Write data
    for (const auto& entry : level_areas) {
        long double lat_start = entry.first.first;
        long double lat_end = entry.first.second;
        long double area = entry.second;

        // Write positive and negative levels
        outfile << lat_start << "," << lat_end << "," << area << std::endl;
        outfile << -lat_end << "," << -lat_start << "," << area << std::endl;
    }

    outfile.close();
    std::cout << "Calculation completed and saved to: " << output_file << std::endl;
    std::cout << "Level Area Calculation Completed. Output saved to: " << output_file << std::endl;

}
