﻿// ConsoleApplication1.cpp : This file contains the 'main' function. Program execution begins and ends there.
/*
This is the main entry point of the program.
It initializes and calls the necessary functions in a structured order,
ensuring smooth execution from start to finish.

*/
// ConsoleApplication1.cpp
#include "header.h"
#include <filesystem>

int main() {
    std::cout << "Starting Energy Calculation Program...\n";

    std::string pre_input_directory = "D:\\Final_Project\\ForStud1\\data\\Pre_input_radiation_files\\";
    std::string input_directory = "D:\\Final_Project\\ForStud1\\data\\input\\";
    std::string output_directory = "D:\\Final_Project\\ForStud1\\data\\output\\";
    std::string energy_output_directory = "D:\\Final_Project\\ForStud1\\data\\output_energy_calculation\\";
    std::string display_output_directory = "D:\\Final_Project\\ForStud1\\data\\DisplayEnergy\\";

    
    // **Step 1: Preparing Pre Data**
    std::vector<std::string> parameters = { "SSRD", "STR", "OLR" };
    for (int year = 2020; year <= 2020; ++year) {
        for (const auto& param : parameters) {
            std::string input_file = pre_input_directory + "Pre_" + param + "_" + std::to_string(year) + ".csv";
            std::string output_file = input_directory + param + "_" + std::to_string(year) + ".csv";

            // Debugging Output
            std::cout << "Checking file: " << input_file << std::endl;

            if (!std::filesystem::exists(input_file)) {
                std::cerr << "ERROR: File does NOT exist: " << input_file << std::endl;
                continue; // Skip this iteration
            }

            process_radiation_data(input_file, output_file, param, year);
        }
    }


    // **Step 2: Slot Association**
    std::cout << "Running Slot Association...\n";
    process_slot_association(input_directory, output_directory, std::thread::hardware_concurrency());

    // **Step 3: Level Area Calculation on ONE file**
    std::cout << "Running Level Area Calculation...\n";
    std::filesystem::path level_area_file = output_directory + "2mtemperature_2020_processed.csv";
    if (std::filesystem::exists(level_area_file)) {
        process_level_area(output_directory, output_directory + "level_area_summary.csv", "2mtemperature_2020_processed.csv");
    }
    else {
        std::cerr << "Error: Level Area input file missing: " << level_area_file << "\n";
    }
    

    // **Step 4: Energy Calculations**
    std::cout << "Running Energy Calculation (Solar Radiation)...\n";
    for (int year = 2020; year <= 2020; ++year) {
        process_energy_radiation(input_directory, energy_output_directory, year);
    }
   
    std::cout << "Running Energy Calculation (Heat Capacity)...\n";
    for (int year = 2020; year <= 2020; ++year) {
       process_energy_capacity(input_directory, energy_output_directory, year);
    }

    
    // **Step 5: Final Data Preparation for Display**
    std::cout << "Running Final Display Data Processing...\n";
    for (int year = 2020; year <= 2020; ++year) {
        preparing_display_data(energy_output_directory, display_output_directory, year);
    }
    

    std::cout << "All Processes Completed Successfully.\n";
    return 0;
}


