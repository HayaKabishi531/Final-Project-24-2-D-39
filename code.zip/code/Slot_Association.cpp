﻿//Slot_Association.cpp
/*
Associates each data point to a specific grid slot on the Earth's surface,
generating a CSV output with both raw data and corresponding geographic coordinates.
*/

#include "header.h"
#include <iostream>
#include <filesystem>

class FileProcessor {
private:
    std::mutex output_mutex;

    std::vector<std::string> split(const std::string& line, char delimiter) {
        std::vector<std::string> tokens;
        std::stringstream ss(line);
        std::string token;
        while (std::getline(ss, token, delimiter))
            tokens.push_back(token);
        return tokens;
    }

    void get_cell_boundaries(double latitude, double longitude, int step,
        double& lat_start, double& lat_end,
        double& lon_start, double& lon_end) {
        int lat_index = static_cast<int>((latitude + 90) / step);
        int lon_index = static_cast<int>((longitude + 180) / step);

        lat_start = lat_index * step - 90;
        lat_end = lat_start + step;
        lon_start = lon_index * step - 180;
        lon_end = lon_start + step;
    }

public:
    void processFile(const std::string& inputFile, const std::string& outputFile) {
        std::ifstream inFile(inputFile);
        std::ofstream outFile(outputFile);

        if (!inFile || !outFile) {
            std::cerr << "Error opening files: " << inputFile << " or " << outputFile << std::endl;
            return;
        }

        std::string header;
        std::getline(inFile, header); // Skip the first line (file name)

        // Write the corrected output header
        outFile << "time_difference,value,latitude point,longitude point,lat_start,lat_end,lon_start,lon_end\n";

        std::string line;
        while (std::getline(inFile, line)) {
            auto tokens = split(line, ',');
            if (tokens.size() < 4) continue;

            try {
                double lat = std::stod(tokens[2]);
                double lon = std::stod(tokens[3]);

                double lat_start, lat_end, lon_start, lon_end;
                get_cell_boundaries(lat, lon, 5, lat_start, lat_end, lon_start, lon_end);

                std::lock_guard<std::mutex> lock(output_mutex);
                outFile << tokens[0] << "," << tokens[1] << "," << tokens[2] << "," << tokens[3] << ","
                    << std::fixed << std::setprecision(1)
                    << lat_start << "," << lat_end << "," << lon_start << "," << lon_end << "\n";
            }
            catch (...) {
                continue;
            }
        }
    }

    // **Function: Process Directory for Slot Association**
    void processDirectoryParallel(const std::string& inputDir, const std::string& outputDir, int threadCount) {
        std::vector<std::future<void>> futures;
        std::atomic<int> processedFiles(0);

        for (const auto& entry : fs::directory_iterator(inputDir)) {
            std::string inputFilePath = entry.path().string();
            std::string fileName = entry.path().filename().string();

            if (fileName.find("processed") != std::string::npos) continue;

            std::string outputFileName = fileName.substr(0, fileName.find('.')) + "_processed.csv";
            std::string outputFilePath = (fs::path(outputDir) / outputFileName).string();

            futures.push_back(std::async(std::launch::async,
                [this, inputFilePath, outputFilePath, &processedFiles]() {
                    this->processFile(inputFilePath, outputFilePath);
                    processedFiles++;
                    std::cout << "Processed file: " << inputFilePath << std::endl;
                }));

            if (futures.size() >= static_cast<size_t>(threadCount)) {
                for (auto& future : futures) future.wait();
                futures.clear();
            }
        }

        for (auto& future : futures) future.wait();
        std::cout << "Total files processed: " << processedFiles.load() << std::endl;
    }
};

void process_slot_association(const std::string& inputDir, const std::string& outputDir, int threadCount) {
    std::cout << "Processing slot association with " << threadCount << " threads..." << std::endl;

    // Ensure output directory exists
    if (!std::filesystem::exists(outputDir)) {
        std::filesystem::create_directories(outputDir);
    }

    // Call directory processing function (assuming it exists)
    FileProcessor processor;
    processor.processDirectoryParallel(inputDir, outputDir, threadCount);

    std::cout << "Slot association processing completed." << std::endl;
}