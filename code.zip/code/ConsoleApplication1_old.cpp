﻿// ConsoleApplication1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "Header.h"
#include <windows.h>
#include <sqlext.h>
#include <sqltypes.h>
#include <sql.h>
//#include "Source1.cpp"



class ClimateData {
public:
	int station_id;
	double parameter;
	int time;
};

class Jump_project
{
public:
	int jump_id_project;
	SQL_TIMESTAMP_STRUCT jump_project_date_created;
	SQLCHAR jump_project_name[256];
	SQLCHAR  jump_project_description[1096];
	SQLCHAR  jump_path_input_global[1096];
	SQLCHAR  jump_path_input_project[1096];
	SQLCHAR  jump_manage_code_global[1096];
	int jump_greed_large_distance;
	int jump_ngreed_small;
	int jump_jump_size_global;
	SQLCHAR jump_path_output_global[1096];
	SQLCHAR jump_path_output_image[1096];
	SQLCHAR jump_dataset[256];
	int jump_delta_time_in_data_global;
	int jump_min_distance_between_stations_global;
};

class Station
{
public:
	int staging_station_id;
	int staging_station_elevation;
	double staging_station_latitude;
	double staging_station_longitude;
};

class StationSelected
{
public:
	int staging_station_id_selected;
	int staging_station_elevation_selected;
	double staging_station_latitude_selected;
	double staging_station_longitude_selected;
};

class Coefficient
{
public:
	int coefficient_day_global;
	double coefficient_jump_size_global;
	int coefficient_wind_for_peaks_global;
	int coefficient_distance_thresh_for_jumps_global;
};

// Function to retrieve data and populate the class
std::vector<Jump_project> fetchDataFromDatabaseProjects(const std::wstring& id, int year, int month, int day) {
	std::vector<Jump_project> dataproject;

	//Initialize connection string 
	std::time_t currentTime;
	std::time(&currentTime); // Get the current time

	std::tm localTime;
	localtime_s(&localTime, &currentTime); // Convert to local time

	// Extract the year, month, and day
	//int year = localTime.tm_year + 1900; // Years since 1900
	//int month = localTime.tm_mon + 1;    // Months are 0-indexed
	//int day = localTime.tm_mday;         // Day of the month

	// Create the formatted string
	std::wstring formattedDate = std::to_wstring(year) + L"_" + (month < 10 ? L"0" : L"") + std::to_wstring(month);

	// Create the connection string
	std::wstring connectionString = L"DRIVER={SQL Server};SERVER=10.78.5.14, 1433;DATABASE=EcoVision_Climate_Parameter_Anomalies_" + formattedDate + L";Trusted=true;PWD=ASFD353fsdPPdsaeAEj904FD353;";
	std::wstring QueryString = L"SELECT [jump_id_project], [jump_project_date_created], [jump_project_name],[jump_project_description], [jump_path_input_global], [jump_path_input_project],[jump_manage_code_global], [jump_greed_large_distance], [jump_ngreed_small], [jump_jump_size_global], [jump_path_output_global], [jump_path_output_image], [jump_dataset], [jump_delta_time_in_data_global], [jump_min_distance_between_stations_global] FROM [dbo].[jump_project] WHERE [jump_id_project] =" + id + L"";

	// Initialize variables
	SQLHENV henv = SQL_NULL_HENV;
	SQLHDBC hdbc = SQL_NULL_HDBC;
	SQLHSTMT hstmt = SQL_NULL_HSTMT;
	SQLRETURN ret;

	// Allocate environment handle
	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	ret = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_UINTEGER);

	// Allocate connection handle
	ret = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);

	// Connect to the database
	ret = SQLDriverConnect(hdbc, NULL, (SQLWCHAR*)connectionString.c_str(), SQL_NTS, NULL, 0, NULL, SQL_DRIVER_COMPLETE);

	// Allocate statement handle
	ret = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);

	// Execute the query
	ret = SQLExecDirect(hstmt, (SQLWCHAR*)QueryString.c_str(), SQL_NTS);

	// Fetch data and populate the vector of class instances
	
	while ((ret = SQLFetch(hstmt)) != SQL_NO_DATA) {
		Jump_project jumpproject;
		
		ret = SQLGetData(hstmt, 1, SQL_C_LONG, &jumpproject.jump_id_project, sizeof(jumpproject.jump_id_project), NULL);
		ret = SQLGetData(hstmt, 2, SQL_C_TYPE_TIMESTAMP, &jumpproject.jump_project_date_created, sizeof(jumpproject.jump_project_date_created), NULL);
		ret = SQLGetData(hstmt, 3, SQL_C_CHAR, &jumpproject.jump_project_name, sizeof(jumpproject.jump_project_name), NULL);
		ret = SQLGetData(hstmt, 4,  SQL_C_CHAR, &jumpproject.jump_project_description, sizeof(jumpproject.jump_project_description), NULL);
		ret = SQLGetData(hstmt, 5,  SQL_C_CHAR, &jumpproject.jump_path_input_global, sizeof(jumpproject.jump_path_input_global), NULL);
		ret = SQLGetData(hstmt, 6,  SQL_C_CHAR, &jumpproject.jump_path_input_project, sizeof(jumpproject.jump_path_input_project), NULL);
	    ret = SQLGetData(hstmt, 7,  SQL_C_CHAR, &jumpproject.jump_manage_code_global, sizeof(jumpproject.jump_manage_code_global), NULL);
		ret = SQLGetData(hstmt, 8,  SQL_C_LONG, &jumpproject.jump_greed_large_distance, sizeof(jumpproject.jump_greed_large_distance), NULL);
		ret = SQLGetData(hstmt, 9,  SQL_C_LONG, &jumpproject.jump_ngreed_small, sizeof(jumpproject.jump_ngreed_small), NULL);
		ret = SQLGetData(hstmt, 10, SQL_C_LONG, &jumpproject.jump_jump_size_global, sizeof(jumpproject.jump_jump_size_global), NULL);
		ret = SQLGetData(hstmt, 11, SQL_C_CHAR, &jumpproject.jump_path_output_global, sizeof(jumpproject.jump_path_output_global), NULL);
		ret = SQLGetData(hstmt, 12, SQL_C_CHAR, &jumpproject.jump_path_output_image, sizeof(jumpproject.jump_path_output_image), NULL);
		ret = SQLGetData(hstmt, 13, SQL_C_CHAR, &jumpproject.jump_dataset, sizeof(jumpproject.jump_dataset), NULL);
		ret = SQLGetData(hstmt, 14, SQL_C_LONG, &jumpproject.jump_delta_time_in_data_global, sizeof(jumpproject.jump_delta_time_in_data_global), NULL);
		ret = SQLGetData(hstmt, 15, SQL_C_LONG, &jumpproject.jump_min_distance_between_stations_global, sizeof(jumpproject.jump_min_distance_between_stations_global), NULL);

		dataproject.push_back(jumpproject);
	}

	// Clean up
	ret = SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
	ret = SQLDisconnect(hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_ENV, henv);

	return dataproject;
}

std::vector<ClimateData> fetchDataFromDatabase(const std::wstring& id, int year, int month, int day) {
	std::vector<ClimateData> data;

	//Initialize connection string 
	 // Get the current time
	std::time_t currentTime;
	std::time(&currentTime); // Get the current time

	std::tm localTime;
	localtime_s(&localTime, &currentTime); // Convert to local time

	// Extract the year, month, and day
	//int year = localTime.tm_year + 1900; // Years since 1900
	//int month = localTime.tm_mon + 1;    // Months are 0-indexed
	//int day = localTime.tm_mday;         // Day of the month

	// Create the formatted string
	std::wstring formattedDate = std::to_wstring(year) + L"_" + (month < 10 ? L"0" : L"") + std::to_wstring(month);

	// Create the connection string
	std::wstring connectionString = L"DRIVER={SQL Server};SERVER=10.78.5.14, 1433;DATABASE=EcoVision_Climate_Parameter_Anomalies_" + formattedDate + L";Trusted=true;PWD=ASFD353fsdPPdsaeAEj904FD353;";

	std::wstring QueryString = L"SELECT [station_id], ROUND([parameter],2) AS [parameter], [time] FROM [EcoVision_Climate_Parameter_Anomalies_" + formattedDate + L"].[dbo].[data_era5] WHERE [jump_id_project] = " + id +  L"";

	// Initialize variables
	SQLHENV henv = SQL_NULL_HENV;
	SQLHDBC hdbc = SQL_NULL_HDBC;
	SQLHSTMT hstmt = SQL_NULL_HSTMT;
	SQLRETURN ret;

	// Allocate environment handle
	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	ret = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_UINTEGER);

	// Allocate connection handle
	ret = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);

	// Connect to the database
	ret = SQLDriverConnect(hdbc, NULL, (SQLWCHAR*)connectionString.c_str(), SQL_NTS, NULL, 0, NULL, SQL_DRIVER_COMPLETE);

	// Allocate statement handle
	ret = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);

	// Execute the query
	ret = SQLExecDirect(hstmt, (SQLWCHAR*)QueryString.c_str(), SQL_NTS);

	// Fetch data and populate the vector of class instances
	while ((ret = SQLFetch(hstmt)) != SQL_NO_DATA) {
		ClimateData climateData;
		ret = SQLGetData(hstmt, 1, SQL_C_LONG, &climateData.station_id, sizeof(climateData.station_id), NULL);
		ret = SQLGetData(hstmt, 2, SQL_C_DOUBLE, &climateData.parameter, sizeof(climateData.parameter), NULL);
		ret = SQLGetData(hstmt, 3, SQL_C_LONG, &climateData.time, sizeof(climateData.time), NULL);
		data.push_back(climateData);
	}

	// Clean up
	ret = SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
	ret = SQLDisconnect(hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_ENV, henv);

	return data;
}

std::vector<Station> fetchDataFromDatabaseStation(int year,int month, int day) {
	std::vector<Station> data;

	//Initialize connection string 
	 // Get the current time
	std::time_t currentTime;
	std::time(&currentTime); // Get the current time

	std::tm localTime;
	localtime_s(&localTime, &currentTime); // Convert to local time

	// Extract the year, month, and day
	//int year = localTime.tm_year + 1900; // Years since 1900
	//int month = localTime.tm_mon + 1;    // Months are 0-indexed
	//int day = localTime.tm_mday;         // Day of the month

	// Create the formatted string
	std::wstring formattedDate = std::to_wstring(year) + L"_" + (month < 10 ? L"0" : L"") + std::to_wstring(month);

	// Create the connection string
	std::wstring connectionString = L"DRIVER={SQL Server};SERVER=10.78.5.14, 1433;DATABASE=EcoVision_Climate_Parameter_Anomalies_" + formattedDate + L";Trusted=true;PWD=ASFD353fsdPPdsaeAEj904FD353;";

	std::wstring QueryString = L"SELECT [station_id],0 AS [elevation] ,[latitude],[longitude] FROM [dbo].[era5_station]";

	// Initialize variables
	SQLHENV henv = SQL_NULL_HENV;
	SQLHDBC hdbc = SQL_NULL_HDBC;
	SQLHSTMT hstmt = SQL_NULL_HSTMT;
	SQLRETURN ret;

	// Allocate environment handle
	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	ret = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_UINTEGER);

	// Allocate connection handle
	ret = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);

	// Connect to the database
	ret = SQLDriverConnect(hdbc, NULL, (SQLWCHAR*)connectionString.c_str(), SQL_NTS, NULL, 0, NULL, SQL_DRIVER_COMPLETE);

	// Allocate statement handle
	ret = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);

	// Execute the query
	ret = SQLExecDirect(hstmt, (SQLWCHAR*)QueryString.c_str(), SQL_NTS);

	// Fetch data and populate the vector of class instances
	while ((ret = SQLFetch(hstmt)) != SQL_NO_DATA) {
		Station stationData;
		ret = SQLGetData(hstmt, 1, SQL_C_LONG, &stationData.staging_station_id, sizeof(stationData.staging_station_id), NULL);
		ret = SQLGetData(hstmt, 2, SQL_C_LONG, &stationData.staging_station_elevation, sizeof(stationData.staging_station_elevation), NULL);
		ret = SQLGetData(hstmt, 3, SQL_C_DOUBLE, &stationData.staging_station_latitude, sizeof(stationData.staging_station_latitude), NULL);
		ret = SQLGetData(hstmt, 4, SQL_C_DOUBLE, &stationData.staging_station_longitude, sizeof(stationData.staging_station_longitude), NULL);
		data.push_back(stationData);
	}

	// Clean up
	ret = SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
	ret = SQLDisconnect(hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_ENV, henv);

	return data;
}

std::vector<StationSelected> fetchDataFromDatabaseStationSelected(int year,int month, int day) {
	std::vector<StationSelected> data;

	//Initialize connection string 
	 // Get the current time
	std::time_t currentTime;
	std::time(&currentTime); // Get the current time

	std::tm localTime;
	localtime_s(&localTime, &currentTime); // Convert to local time

	// Extract the year, month, and day
	//int year = localTime.tm_year + 1900; // Years since 1900
	//int month = localTime.tm_mon + 1;    // Months are 0-indexed
	//int day = localTime.tm_mday;         // Day of the month

	// Create the formatted string
	std::wstring formattedDate = std::to_wstring(year) + L"_" + (month < 10 ? L"0" : L"") + std::to_wstring(month);

	// Create the connection string
	std::wstring connectionString = L"DRIVER={SQL Server};SERVER=10.78.5.14, 1433;DATABASE=EcoVision_Climate_Parameter_Anomalies_" + formattedDate + L";Trusted=true;PWD=ASFD353fsdPPdsaeAEj904FD353;";

	std::wstring QueryString = L"SELECT [station_id],0 AS [elevation] ,[latitude],[longitude] FROM [dbo].[era5_station] WHERE [is_active] = 1";

	// Initialize variables
	SQLHENV henv = SQL_NULL_HENV;
	SQLHDBC hdbc = SQL_NULL_HDBC;
	SQLHSTMT hstmt = SQL_NULL_HSTMT;
	SQLRETURN ret;

	// Allocate environment handle
	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	ret = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_UINTEGER);

	// Allocate connection handle
	ret = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);

	// Connect to the database
	ret = SQLDriverConnect(hdbc, NULL, (SQLWCHAR*)connectionString.c_str(), SQL_NTS, NULL, 0, NULL, SQL_DRIVER_COMPLETE);

	// Allocate statement handle
	ret = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);

	// Execute the query
	ret = SQLExecDirect(hstmt, (SQLWCHAR*)QueryString.c_str(), SQL_NTS);

	// Fetch data and populate the vector of class instances
	while ((ret = SQLFetch(hstmt)) != SQL_NO_DATA) {
		StationSelected stationSelected;
		ret = SQLGetData(hstmt, 1, SQL_C_LONG, &stationSelected.staging_station_id_selected, sizeof(stationSelected.staging_station_id_selected), NULL);
		ret = SQLGetData(hstmt, 2, SQL_C_LONG, &stationSelected.staging_station_elevation_selected, sizeof(stationSelected.staging_station_elevation_selected), NULL);
		ret = SQLGetData(hstmt, 3, SQL_C_DOUBLE, &stationSelected.staging_station_latitude_selected, sizeof(stationSelected.staging_station_latitude_selected), NULL);
		ret = SQLGetData(hstmt, 4, SQL_C_DOUBLE, &stationSelected.staging_station_longitude_selected, sizeof(stationSelected.staging_station_longitude_selected), NULL);
		data.push_back(stationSelected);
	}

	// Clean up
	ret = SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
	ret = SQLDisconnect(hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_ENV, henv);

	return data;
}

std::vector<Coefficient> fetchDataFromDatabaseCoefficient(const std::wstring& id, int year, int month, int day) {
	std::vector<Coefficient> data;

	//Initialize connection string 
	 // Get the current time
	std::time_t currentTime;
	std::time(&currentTime); // Get the current time

	std::tm localTime;
	localtime_s(&localTime, &currentTime); // Convert to local time

	// Extract the year, month, and day
	//int year = localTime.tm_year + 1900; // Years since 1900
	//int month = localTime.tm_mon + 1;    // Months are 0-indexed
	//int day = localTime.tm_mday;         // Day of the month

	// Create the formatted string
	std::wstring formattedDate = std::to_wstring(year) + L"_" + (month < 10 ? L"0" : L"") + std::to_wstring(month);

	// Create the connection string
	std::wstring connectionString = L"DRIVER={SQL Server};SERVER=10.78.5.14, 1433;DATABASE=EcoVision_Climate_Parameter_Anomalies_" + formattedDate + L";Trusted=true;PWD=ASFD353fsdPPdsaeAEj904FD353;";

	std::wstring QueryString = L"SELECT [coefficient_day_global],[coefficient_jump_size_global],[coefficient_distance_thresh_for_jumps_global],[coefficient_wind_for_peaks_global] FROM [dbo].[jump_coefficient] WHERE [jump_id_project] =" + id + L"";

	// Initialize variables
	SQLHENV henv = SQL_NULL_HENV;
	SQLHDBC hdbc = SQL_NULL_HDBC;
	SQLHSTMT hstmt = SQL_NULL_HSTMT;
	SQLRETURN ret;

	// Allocate environment handle
	ret = SQLAllocHandle(SQL_HANDLE_ENV, SQL_NULL_HANDLE, &henv);
	ret = SQLSetEnvAttr(henv, SQL_ATTR_ODBC_VERSION, (SQLPOINTER)SQL_OV_ODBC3, SQL_IS_UINTEGER);

	// Allocate connection handle
	ret = SQLAllocHandle(SQL_HANDLE_DBC, henv, &hdbc);

	// Connect to the database
	ret = SQLDriverConnect(hdbc, NULL, (SQLWCHAR*)connectionString.c_str(), SQL_NTS, NULL, 0, NULL, SQL_DRIVER_COMPLETE);

	// Allocate statement handle
	ret = SQLAllocHandle(SQL_HANDLE_STMT, hdbc, &hstmt);

	// Execute the query
	ret = SQLExecDirect(hstmt, (SQLWCHAR*)QueryString.c_str(), SQL_NTS);

	// Fetch data and populate the vector of class instances
	while ((ret = SQLFetch(hstmt)) != SQL_NO_DATA) {
		Coefficient coefficient_jump;
		ret = SQLGetData(hstmt, 1, SQL_C_LONG, &coefficient_jump.coefficient_day_global, sizeof(coefficient_jump.coefficient_day_global), NULL);
		ret = SQLGetData(hstmt, 2, SQL_C_DOUBLE, &coefficient_jump.coefficient_jump_size_global, sizeof(coefficient_jump.coefficient_jump_size_global), NULL);
		ret = SQLGetData(hstmt, 3, SQL_C_LONG, &coefficient_jump.coefficient_distance_thresh_for_jumps_global, sizeof(coefficient_jump.coefficient_distance_thresh_for_jumps_global), NULL);
		ret = SQLGetData(hstmt, 4, SQL_C_LONG, &coefficient_jump.coefficient_wind_for_peaks_global, sizeof(coefficient_jump.coefficient_wind_for_peaks_global), NULL);
		data.push_back(coefficient_jump);
	}

	// Clean up
	ret = SQLFreeHandle(SQL_HANDLE_STMT, hstmt);
	ret = SQLDisconnect(hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_DBC, hdbc);
	ret = SQLFreeHandle(SQL_HANDLE_ENV, henv);

	return data;
}

//int main(int argc, wchar_t* argv[])
int main()
{
	ofstream fout;
		//std::wstring id = argv[1];

	int i, j, tmin = 0, tmax = 0;
	
		//Folder
		// Get the current time
		std::time_t currentTime;
		std::time(&currentTime); // Get the current time

		std::tm localTime;
		localtime_s(&localTime, &currentTime); // Convert to local time

		// Extract the year, month, and day
		int year = localTime.tm_year + 1900; // Years since 1900
		int month = localTime.tm_mon + 1;    // Months are 0-indexed
		int day = localTime.tm_mday;         // Day of the month

		// Create the formatted string
		std::string formattedDate = std::to_string(year) + "_" + (month < 10 ? "0" : "") + std::to_string(month) + "_" + (day < 10 ? "0" : "") + std::to_string(day);
/*

		Clim cc1;

		//Define configuration plan
		std::vector<Jump_project> fetchProject = fetchDataFromDatabaseProjects(id, year, month, day);

		cc1.Path1_Input_glob = reinterpret_cast<const char*>(fetchProject[0].jump_path_input_global);

		cc1.Path2_Input_glob = std::string(reinterpret_cast<const char*>(fetchProject[0].jump_path_input_project)) + std::string(reinterpret_cast<const char*>(fetchProject[0].jump_project_name)) + "\\" + formattedDate + "\\";

		cc1.Path1_Output_glob = std::string(reinterpret_cast<const char*>(fetchProject[0].jump_path_output_global)) + std::string(reinterpret_cast<const char*>(fetchProject[0].jump_project_name)) + "\\" + formattedDate + "\\result\\";

		cc1.Path1_Output_clust_glob = std::string(reinterpret_cast<const char*>(fetchProject[0].jump_path_output_global)) + std::string(reinterpret_cast<const char*>(fetchProject[0].jump_project_name)) + "\\" + formattedDate + "\\cluster\\";

		cc1.Path1_Output_pict1_glob = std::string(reinterpret_cast<const char*>(fetchProject[0].jump_path_output_image)) + std::string(reinterpret_cast<const char*>(fetchProject[0].jump_project_name)) + "\\" + formattedDate + "\\image\\";

		cc1.ManageCode_glob = reinterpret_cast<const char*>(fetchProject[0].jump_manage_code_global);


		cc1.GreedLarge1dist1_Glob = fetchProject[0].jump_greed_large_distance;
		cc1.NgreedSmall1_Glob = fetchProject[0].jump_ngreed_small;
		cc1.JumpSzGlob = fetchProject[0].jump_jump_size_global;
		cc1.DeltaTimeInDataGlob = fetchProject[0].jump_delta_time_in_data_global;
		cc1.PointsInDayGlob = 1440 / cc1.DeltaTimeInDataGlob;
		cc1.MinDistBetweenStationsGlob = fetchProject[0].jump_min_distance_between_stations_global;

		//Call data
		std::vector<ClimateData> fetchedData = fetchDataFromDatabase(id, year, month, day);


		cc1.consol = 1;

		std::vector<Station> stations = fetchDataFromDatabaseStation(year, month, day);
		std::vector<StationSelected> station_selected = fetchDataFromDatabaseStationSelected(year, month, day);


		//Station and station select
		Stat1 st;
		st.elevation = 0;
		st.id_count = -1;
		st.model = -1;
		st.lon = 0.001;
		st.lat = 0.001;
		st.last = 0;
		st.index = -1;
		st.flag = -1;

		cc1.Stat1_glob.push_back(st);
		for (size_t i = 0; i < stations.size(); ++i) //*
		{
			if (stations[i].staging_station_id < 0) continue;
			if (stations[i].staging_station_id >= cc1.Stat1_glob.size())
				for (j = cc1.Stat1_glob.size(); j <= stations[i].staging_station_id; j++)
					cc1.Stat1_glob.push_back(st);

			cc1.Stat1_glob[stations[i].staging_station_id].elevation = stations[i].staging_station_elevation;
			cc1.Stat1_glob[stations[i].staging_station_id].lat = stations[i].staging_station_latitude;
			cc1.Stat1_glob[stations[i].staging_station_id].lon = stations[i].staging_station_longitude;
			cc1.Stat1_glob[stations[i].staging_station_id].model = 0;
		}
		//cc1.ReadSelect1(cc1.Path2_Input_glob);

		for (size_t i = 0; i < station_selected.size(); ++i) //selected
			if (station_selected[i].staging_station_id_selected >= 0 && station_selected[i].staging_station_id_selected < cc1.Stat1_glob.size())
				cc1.select1_glob.push_back(station_selected[i].staging_station_id_selected);

		for (i = 0; i < cc1.select1_glob.size(); i++)
			cc1.Stat1_glob[cc1.select1_glob[i]].index = i;

		fout.open(cc1.Path1_Output_glob + "stat_c", ios::out);
		for (i = 0; i < cc1.select1_glob.size(); i++)
			fout << cc1.select1_glob[i] << " " << cc1.Stat1_glob[cc1.select1_glob[i]].elevation << " " << cc1.Stat1_glob[cc1.select1_glob[i]].lat
			<< " " << cc1.Stat1_glob[cc1.select1_glob[i]].lon << "\n";
		fout.close();
		//

		vector <Point3> data;
		Point3 pt3;

		int tmin = 999999999;
		int tmax = -999999999;

		for (const auto& data1 : fetchedData)
		{
			if (data1.station_id < 0 || data1.station_id >= cc1.Stat1_glob.size()) continue;
			//if (cc1.Stat1_glob[sts[i]].index < 0) continue;

			if (data1.parameter == 10000 || data1.time == 10000) continue;

			pt3.time = data1.time;
			pt3.temper = data1.parameter;
			pt3.st = data1.station_id;

			if (tmin > pt3.time) tmin = pt3.time;
			if (tmax < pt3.time) tmax = pt3.time;

			data.push_back(pt3);
		}

		//ofstream fout;
		fout.open(cc1.Path1_Output_glob + "data_c", ios::out);

		for (i = 0; i < data.size(); i++)
			fout << data[i].st << " " << data[i].temper << " " << data[i].time << "\n";

		fout.close();
		///////////////////////////////////////////////
		if (cc1.ManageCode_glob[3] != '0')
			cc1.MakeGreed1();
		/////////////////////////////////
		cc1.Nt1_glob = int((tmax - tmin) / double(cc1.DeltaTimeInDataGlob)) + 1;



		int Nst = cc1.select1_glob.size();
		cc1.tmp1 = new short* [Nst];
		for (j = 0; j < Nst; j++)
			cc1.tmp1[j] = new short[cc1.Nt1_glob];

		for (i = 0; i < Nst; i++)
			for (j = 0; j < cc1.Nt1_glob; j++)
				cc1.tmp1[i][j] = 10000;

		for (i = 0; i < data.size(); i++)
		{
			if (data[i].temper != 10000)
			if (cc1.Stat1_glob[data[i].st].index >= 0)
				cc1.tmp1[cc1.Stat1_glob[data[i].st].index][int((data[i].time - tmin) / double(cc1.DeltaTimeInDataGlob))] = short(data[i].temper * mulipluIndex_glob);
		}

		cc1.ReadData1Small3_FromMas1();
		//////////////////////////////////////////////////////////////////////////////////

		std::vector<Coefficient> cofficient_jumps = fetchDataFromDatabaseCoefficient(id, year, month, day);

		cc1.Wind1ForJumps_glob = cc1.PointsInDayGlob * cofficient_jumps[0].coefficient_day_global;
		cc1.Tresh1ForJumps_glob = cc1.Avarage1_Glob * cc1.JumpSzGlob * cofficient_jumps[0].coefficient_jump_size_global;
		cc1.distThresh1ForJumps_glob = cofficient_jumps[0].coefficient_distance_thresh_for_jumps_global;
		cc1.Wind1ForPeaks_glob = cofficient_jumps[0].coefficient_wind_for_peaks_global;

		fout.open(cc1.Path1_Output_glob + "parameters_c", ios::out);

		fout << "Wind1ForJumps_glob =" << cc1.Wind1ForJumps_glob << "\n";
		fout << "Tresh1ForJumps_glob =" << cc1.Tresh1ForJumps_glob << "\n";
		fout << "distThresh1ForJumps_glob =" << cc1.distThresh1ForJumps_glob << "\n";
		fout << "Wind1ForPeaks_glob =" << cc1.Wind1ForPeaks_glob << "\n";
		fout << "PointsInDayGlob =" << cc1.PointsInDayGlob << "\n";
		fout << "GreedLarge1dist1_Glob =" << cc1.GreedLarge1dist1_Glob << "\n";
		fout << "NgreedSmall1_Glob =" << cc1.NgreedSmall1_Glob << "\n";
		fout << "JumpSzGlob =" << cc1.JumpSzGlob << "\n";
		fout << "DeltaTimeInDataGlob =" << cc1.DeltaTimeInDataGlob << "\n";
		fout << "MinDistBetweenStationsGlob =" << cc1.MinDistBetweenStationsGlob << "\n";
		fout << "Nt1_glob =" << cc1.Nt1_glob << "\n";
		fout << "tmin = " << tmin << "   tmax =" << tmax << "\n";

		fout.close();

		if (cc1.ManageCode_glob[4] != '0')
		{
			cc1.JumpMap1();
			cc1.Jump_anal1();
			if (cc1.ManageCode_glob[3] != '0')
				cc1.Greed_anal1();
			//		cc1.SigTrans1();
			if (cc1.ManageCode_glob[5] != '0' && cc1.ManageCode_glob[3] != '0')
				cc1.MakeClust1();
		}
	*/


	Clim cc1;
	/*
		double TT, TTd, Rh = 1.0;
		while (Rh != 0.0)
		{
			cerr << "\nT=";
			cin >> TT;
			cerr << "  Td=";
			cin >> TTd;
			Rh = cc1.RHfromTd(TT, TTd);
			cerr << "  Rh=" << Rh << "\nRo =" << cc1.calculateSaturatedVaporDensity(TT)
				<< "\nAW =" << Rh*cc1.calculateSaturatedVaporDensity(TT);
		}
	*/


	cc1.startingDate_glob = { 0, 0, 0, 1, 0, 100 }; // 1 Jenuary 2000 (year is 1900-based)
	// Convert starting date to time_t (seconds since epoch)
	cc1.t1_glob = std::mktime(&cc1.startingDate_glob);





	cc1.consol = 1;
	//	cc1.Path1_Input_glob = "c:\\Users\\user\\OneDrive - Emnotion Ltd\\осолйн\\SQL Server Management Studio\\DATA\\";
	//	cc1.Path2_Input_glob = "c:\\Users\\user\\OneDrive - Emnotion Ltd\\осолйн\\SQL Server Management Studio\\DATA\\";
	cc1.Path1_Input_glob = "c:\\Users\\user\\source\\DATA1\\";
	//	cc1.Path2_Input_glob = "c:\\Users\\user\\source\\DATA1\\";
	//	cc1.Path2_Input_glob = "d:\\Results-11_01_23\\2013\\";
	//	cc1.Path2_Input_glob = "d:\\rain\\2014_12_01\\result\\"; 
	//	cc1.Path2_Input_glob = "d:\\Entropy1\\History by hour\\";
	cc1.Path2_Input_glob = "d:\\Entropy1\\EARTH\\";


	cc1.Path1_Output_glob = "";
	cc1.Path1_Output_clust_glob = "";
	cc1.Path1_Output_pict1_glob = "";
	//cc1.InputFname_glob = "11.csv";
	cc1.InputFname_glob = "data_c";

	cc1.ManageCode_glob = "111111111";

	cc1.GreedLarge1dist1_Glob = 200000;
	cc1.NgreedSmall1_Glob = 50;
	cc1.JumpSzGlob = 50;
	//	cc1.JumpSzGlob = 10;
	cc1.DeltaTimeInDataGlob = 1440;
	cc1.PointsInDayGlob = 1440 / cc1.DeltaTimeInDataGlob;
	cc1.MinDistBetweenStationsGlob = 0;
	//	cc1.MinDistBetweenStationsGlob = 50000;

	cc1.Wind1ForJumps_glob = cc1.PointsInDayGlob * 5;
	cc1.Tresh1ForJumps_glob = cc1.Avarage1_Glob * cc1.JumpSzGlob * 0.01;
	cc1.distThresh1ForJumps_glob = 1000000;
	cc1.Wind1ForPeaks_glob = 60;

	cc1.JumpDownYes_Glob = 1;
	cc1.JumpUpYes_Glob = 1;
	cc1.MakeClustersJumps_Glob = 0;
	cc1.MakePictures_Glob = 0;
	cc1.distThreshforClust1_glob = 300000;
	//	cc1.TreshClust2_glob = 4;
	cc1.MinDistNewBorn_glob = 1000000;
	cc1.Stat_select_glob = 1;

	cc1.CSVfile_vertical_glob = 0;
	cc1.MakeGreed1_help_glob = 1;


	cc1.JumpClustersOnly = 1;
	cc1.SaveLargeFiles_glob = 1;

	cc1.mulipluIndex_glob = 10;

	////////////////////
	//entropy
	//cc1.Entropy1_Anal1();
	cc1.ReadData_entropy1_greed();
	return 0;
	////////////////////////////////////

	//////////////////////////////////////////////

	//Stat1_glob[Data_entropy1_mas1_glob[i].stat].index = select1_glob.size();
	//select1_glob
	//*
	string fname = cc1.Path1_Output_glob + "station_entrop.csv";
	fout.open(fname.c_str(), ios::out);
	if (!fout.good()) cc1.error(fname.c_str());

	fout << "station_id,latitude,longitude";
	for (i = 0; i < cc1.Stat1_glob.size(); i++)
		if (cc1.Stat1_glob[i].index != -1)
			fout << "\n" << i << "," << cc1.Stat1_glob[i].lat << "," << cc1.Stat1_glob[i].lon;

	fout.close();

	cc1.MakeGreed1_help_glob = 0;
	cc1.MakeGreed1();

	cc1.NtMax_glob = 24;
	int Nst = cc1.select1_glob.size();
	int Nt = cc1.NtMax_glob;
	cc1.tmp1 = new short* [Nst];
	cc1.prs1d = new double* [Nst];
	cc1.hmd1 = new short* [Nst];
	cc1.hmdAbs1 = new double* [Nst];

	cc1.Data_entropy1_mas1_glob.reserve(Nst*Nt);

	for (j = 0; j < Nst; j++)
	{
		cc1.tmp1[j] = new short[Nt];
		cc1.prs1d[j] = new double[Nt];
		cc1.hmd1[j] = new short[Nt];
		cc1.hmdAbs1[j] = new double[Nt];
	}

	//Call data
	std::vector<ClimateData> fetchedData;
	fetchedData.reserve(Nst * Nt);

	Data_entropy1 de1;

	cc1.year1_glob = 2024;//year;
	cc1.month1_glob = 3;//month;
	cc1.day1_glob = 10;// day;

	int year0 = cc1.year1_glob;
	int month0 = cc1.month1_glob;
	int day0 = cc1.day1_glob;

	char buf[1000];
	for (i = 1; i <= 3; i++)
	{
		sprintf_s(buf, "data_entrop_%i", i);
		fname = cc1.Path1_Output_glob + buf;
		fout.clear();
		fout.open(fname, ios::out);
		int k = 0;

		//cc1.Data_entropy1_mas1_glob.clear();
		//fetchedData.clear();
		fetchedData = fetchDataFromDatabase(id, cc1.year1_glob, cc1.month1_glob, cc1.day1_glob);
		for (const auto& data1 : fetchedData)
		{
			if (data1.station_id < 0 || data1.station_id >= cc1.Stat1_glob.size()) continue;

			if (data1.parameter == 10000 || data1.time == 10000) continue;

			de1.time = data1.time;
			de1.temp = data1.parameter;
			de1.pressure = data1.pressure;
			de1.dew_point = data1.dew_point;
			de1.stat = data1.station_id;

			cc1.Data_entropy1_mas1_glob.push_back(de1);
			fout << "\n" << k << " " << data1.time << " " << data1.station_id << " " << data1.parameter
				<< " " << data1.parameter << " " << data1.parameter << "\n";
			k++;
		}

		fout.close();
		cc1.DateProceed2(year0, month0, day0, i);
	}

	cc1.Entropy1_Anal1_SQL_cyc(year0, month0, day0);
	cc1.ReadData_entropy1_greed_SQL();





	//*/



	///////////////////////////////////////////////////
	//flows
	cc1.MinDistBetweenStationsGlob = 50000;
	cc1.GreedLarge1dist1_Glob = 500000;
//	cc1.MakeGreed1_help_glob = 0;
	cc1.SaveLargeFiles_glob = 0;
	cc1.ReadStat1_csv(cc1.Path1_Input_glob);
	cc1.ReadSelect1(cc1.Path1_Input_glob);
	cc1.MakeGreed1();
	cc1.OverYearsAnal1_flow();
//	cc1.OverYearsAnal2();
	return 0;
	////////////////////////////////////



	/*///////////////////////////////////////////////////
	cc1.MinDistBetweenStationsGlob = 0;
	cc1.SaveLargeFiles_glob = 0;
	cc1.ReadStat1_csv(cc1.Path1_Input_glob);
	cc1.ReadSelect1(cc1.Path1_Input_glob);
	cc1.MakeGreed1();
//	cc1.ReadStat1_csv(cc1.Path1_Input_glob);
//	cc1.ReadSelect1(cc1.Path1_Input_glob);
//	cc1.OverYearsAnal1();
	cc1.OverYearsAnal2();
	return 0;
	////////////////////////////////////


	if (cc1.JumpClustersOnly == 1)
	{
		cc1.ReadStat1_csv(cc1.Path1_Input_glob);
		cc1.ReadSelect1(cc1.Path1_Input_glob);
//		cc1.Read_data_subgr1_days(cc1.Path2_Input_glob);
//		cc1.Sdvig_calc1(cc1.Path2_Input_glob);
//		return 0;

		cc1.MakeGreed1();

		cc1.Tresh1ForJumps_glob = 30.0;
		cc1.ResultAnalysis1(); //read jumps

		cc1.COUNT1_glob = 0;
		cc1.Read_data_subgr1_days(cc1.Path2_Input_glob);

		cc1.Jump_anal1();
		cc1.Greed_anal1();
	//	return 0;

		cc1.MakePictures_Glob = 0;
		cc1.MakeClust2();
		cc1.Clust1Born1();
		return 0;
	}

	//*/
	//cc1.ReadData1_sky(); return (0);

//	cc1.ReadModels_connect(path1);
//	cc1.ReadStat1(cc1.Path1_Input_glob);
	cc1.ReadStat1_csv(cc1.Path1_Input_glob);
	cc1.ReadSelect1(cc1.Path1_Input_glob);

	fout.open(cc1.Path1_Output_glob + "stat_c", ios::out);
	for (i = 0; i < cc1.select1_glob.size(); i++)
		fout << cc1.select1_glob[i] << " " << cc1.Stat1_glob[cc1.select1_glob[i]].elevation << " " << cc1.Stat1_glob[cc1.select1_glob[i]].lat
		<< " " << cc1.Stat1_glob[cc1.select1_glob[i]].lon << "\n";
	fout.close();

	/////////////////////////rain
//	c1.ReadStat1_csv(cc1.Path1_Input_glob);
//	cc1.ReadSelect1(cc1.Path1_Input_glob);
	cc1.mulipluIndex_glob = 100;
//	cc1.ReadData1Small3(cc1.Path2_Input_glob);
//	cc1.Rain_anal1();
	cc1.MakeGreed1_help_glob = 0;
	cc1.MakeGreed1();
	return 0;
	cc1.tmin_glob = tmin;
	cc1.tmax_glob = tmax;
	cc1.CurrentYearsAnal1_rain();
//	cc1.OverYearsAnal1_rain();
	return 0;
	/////////////////////////////

	/////////////////////////////////////
	//for nabours 
	//cc1.distThreshforClust1_glob = 200000;
	//cc1.MakeGreed1();
	//cc1.MakeClust2();
	/////////////////////////////////////
	//

	//	cc1.ReadModelStat(path1);
	//	cc1.MakeStationSubgroup1();
	//	cc1.ReadData2(cc1.Path1_Input_glob);

	//	cc1.ReadData3(cc1.Path1_Input_glob);
	//	return(0);

	//	cc1.CalcDistManual(); return(0);
	//	cc1.ReadData1(); return(0);
	//	cc1.ReadData1Small2(path2);

	if (cc1.ManageCode_glob[3] != '0')
		cc1.MakeGreed1();
	////
	//cc1.MakeClust2();
	//cc1.MakeEathGreed1();

	cc1.ReadData1Small3(cc1.Path2_Input_glob);

	cc1.Tresh1ForJumps_glob = cc1.Avarage1_Glob * cc1.JumpSzGlob * 0.01;

	fout.open(cc1.Path1_Output_glob + "parameters_c", ios::out);

	fout << "Wind1ForJumps_glob =" << cc1.Wind1ForJumps_glob << "\n";
	fout << "Tresh1ForJumps_glob =" << cc1.Tresh1ForJumps_glob << "\n";
	fout << "distThresh1ForJumps_glob =" << cc1.distThresh1ForJumps_glob << "\n";
	fout << "Wind1ForPeaks_glob =" << cc1.Wind1ForPeaks_glob << "\n";
	fout << "PointsInDayGlob =" << cc1.PointsInDayGlob << "\n";
	fout << "GreedLarge1dist1_Glob =" << cc1.GreedLarge1dist1_Glob << "\n";
	fout << "NgreedSmall1_Glob =" << cc1.NgreedSmall1_Glob << "\n";
	fout << "JumpSzGlob =" << cc1.JumpSzGlob << "\n";
	fout << "DeltaTimeInDataGlob =" << cc1.DeltaTimeInDataGlob << "\n";
	fout << "MinDistBetweenStationsGlob =" << cc1.MinDistBetweenStationsGlob << "\n";
	fout << "Nt1_glob =" << cc1.Nt1_glob << "\n";
	fout << "distThreshforClust1_glob =" << cc1.distThreshforClust1_glob << "\n";
	fout << "MinDistNewBorn_glob =" << cc1.MinDistNewBorn_glob << "\n";
	fout << "ManageCode_glob = " << cc1.ManageCode_glob << "\n";
//	fout << "tmin = " << tmin << "   tmax =" << tmax << "\n";

	fout.close();


	//	return(0);

	if (cc1.ManageCode_glob[4] != '0')
	{
		cc1.JumpMap1();
		if (cc1.ManageCode_glob[3] != '0')
		{
			cc1.Jump_anal1();
			cc1.Greed_anal1();
		}

		//cc1.SigTrans1();
		if (cc1.ManageCode_glob[5] != '0' && cc1.ManageCode_glob[3] != '0')
		{
		//	cc1.MakeClust1();
			cc1.MakeClust2();
			cc1.Clust1Born1();
		}
	}


	//	return(0);

	//	cc1.MakePict1();  return(0);
	//	cc1.ReadData1Small1(); 
		//cc1.DM1();

	//	return (0);
	//	cc1.MakeTube1();
	//	cc1.DrowStations();
	//	cc1.DrowStationsSubgroup1();
	//	cc1.JumpMap1();
	//	cc1.SigTrans1();
	//	cc1.MakeClust1();

}
