﻿//Energy_based_on_temperature_capacity.cpp
/*
Calculates energy absorption based on temperature and heat capacity, 
using the COOLPROP library for humidity and heat capacity calculations, and outputs annual data.
*/
#include "header.h"
#include "CoolProp.h"
#include "HumidAirProp.h"
#include <mutex>


// --- Humidity Function ---
inline double RHfromTd(double T, double Td) {
    double Rh = 0.0;
    double a = 6.1121;
    double b = (T >= 0) ? 17.368 : 17.966;
    double c = (T >= 0) ? 238.88 : 247.15;
    double d = 234.5;

    if (T >= 99 || Td >= 99) return Rh;
    if (T < -100 || Td < -200) return Rh;

    double e = exp((b - T / d) * T / (c + T));
    double gammaM = (b * Td) / (c + Td);
    Rh = exp(gammaM) / e;
    return (Rh > 1) ? 1.0 : Rh;
}

// --- Compute Heat Capacity ---
inline double compute_heat_capacity(double temperature, double pressure, double humidity) {
    double temp_K = temperature + 273.15;
    return HumidAir::HAPropsSI("C", "T", temp_K, "P", pressure, "R", humidity) * 1000.0;
}


// --- Read CSV Files ---
std::map<std::tuple<double, double, double>, DataPoint> read_csv(const std::string& file_path) {
    std::ifstream file(file_path);
    if (!file.is_open()) {
        throw std::runtime_error("Failed to open file: " + file_path);
    }

    std::map<std::tuple<double, double, double>, DataPoint> data_map;
    std::string line;
    std::getline(file, line); // Skip header

    while (std::getline(file, line)) {
        std::istringstream ss(line);
        DataPoint entry;
        char comma;

        ss >> entry.time_difference >> comma >> entry.value >> comma >> entry.latitudepoint >> comma >> entry.longitudepoint >> comma;
      
        auto key = std::make_tuple(entry.time_difference, entry.latitudepoint, entry.longitudepoint);
        data_map[key] = entry;
    }

    return data_map;
}

// --- Read Area Data ---
std::map<std::pair<double, double>, double> read_area_data(const std::string& file_path) {
    std::cout << "Reading level area data from: " << file_path << std::endl;

    std::ifstream file(file_path);
    if (!file.is_open()) {
        throw std::runtime_error("Error: Failed to open level area file: " + file_path);
    }

    std::map<std::pair<double, double>, double> area_map;
    std::string line;
    std::getline(file, line); // Skip header

    while (std::getline(file, line)) {
        std::istringstream ss(line);
        double start_lat, end_lat, area;
        char comma;
        ss >> start_lat >> comma >> end_lat >> comma >> area;

        area_map[{start_lat, end_lat}] = area;
    }

    return area_map;
}



// --- Compute Energy Absorption ---
void calculate_energy(const std::map<std::tuple<double, double, double>, DataPoint>& temp_data,
    const std::map<std::tuple<double, double, double>, DataPoint>& dewpoint_data,
    const std::map<std::tuple<double, double, double>, DataPoint>& pressure_data,
    const std::map<std::pair<double, double>, double>& area_data,
    const std::string& output_file) {

    std::ofstream out(output_file);
    if (!out.is_open()) {
        throw std::runtime_error("Failed to open output file: " + output_file);
    }

    out << "Time_difference,local_hour,Latitude,Longitude,Energy_Value\n";


    for (const auto& [key, temp_entry] : temp_data) {
        auto it_dew = dewpoint_data.find(key);
        auto it_press = pressure_data.find(key);

        if (it_dew == dewpoint_data.end() || it_press == pressure_data.end()) continue;

        double humidity = RHfromTd(temp_entry.value, it_dew->second.value);
        double heat_capacity = compute_heat_capacity(temp_entry.value, it_press->second.value, humidity);
        double delta_T = temp_entry.value - it_dew->second.value;

        double  end_latitude = temp_entry.latitudepoint + 5;
        auto area_it = area_data.find({ temp_entry.latitudepoint,end_latitude});
        if (area_it == area_data.end()) continue;

        double energy = area_it->second * heat_capacity * delta_T;
        
        // Correct Local Time Calculation (Local time resets at 1440 minutes)
        int local_hour = (static_cast<int>(temp_entry.time_difference) % 1440) / 60; // Extract hour of the day (0-23)

        out << std::fixed << std::setprecision(1)
            << temp_entry.time_difference << ','
            << local_hour << ','
            << temp_entry.latitudepoint << ',' << temp_entry.longitudepoint << ','
            << energy << '\n';
       
    }

    out.close();

}

// --- Process Energy Based on Heat Capacity ---
void process_energy_capacity(const std::string& input_folder,const std::string& output_folder,int year) {

   
    std::string level_area_path = input_folder + "level_area_summary.csv";  // Fix: Read from input folder


    if (!std::filesystem::exists(level_area_path)) {
        std::cerr << "Error: Level Area input file missing: " << level_area_path << std::endl;
        return;
    }

    auto area_data = read_area_data(level_area_path);
    
    auto temp_data = read_csv(input_folder + "2mtemperature_" + std::to_string(year) + ".csv");
    auto dew_data = read_csv(input_folder + "2mdewpointtemperature_" + std::to_string(year) + ".csv");
    auto press_data = read_csv(input_folder + "Surfacepressure_" + std::to_string(year) + ".csv");

    std::string output_file = output_folder + "Capacity_Energy_Absorption_" + std::to_string(year) + ".csv";

    calculate_energy(temp_data, dew_data, press_data, area_data, output_file);

    std::cout << "Processed heat capacity energy for year " << year << ". Output saved: " << output_file << std::endl;
}
