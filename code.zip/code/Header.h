/*
Contains library imports, structure definitions, 
and function declarations,
which serve as the main interface for the other code files.
*/
#ifndef HEADER_H
#define HEADER_H

#define NO_MIN_MAX
#define NOMINMAX

#include <windows.h>
#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <list>
#include <cmath>
#include <direct.h>
#include <cstdlib>
#include <map>
#include <tuple>
#include <filesystem>
#include <unordered_map>
#include <thread>
#include <set>
#include <atomic>  
#include <future>
#include <algorithm>
#include <functional>
#include "CoolProp.h"
#include "HumidAirProp.h"
#include <mutex>

// Constants
#define PI 3.14159265358979323846
#define EARTH_RADIUS 6371.0 // Earth's radius in kilometers
#define DEG_TO_RAD (PI / 180.0)
#define MINUTES_IN_HOUR  60
#define HOURS_IN_DAY 24
#define MINUTES_IN_DAY  (HOURS_IN_DAY * MINUTES_IN_HOUR)
#define MAX_TIME   1380 //525600  // Ensuring output goes up to 2880 minutes
#define PEAK_HOUR   12 // Midday gets the highest energy  
#define WIDTH   6.0    // Controls how spread out the energy 


using namespace std;
namespace fs = std::filesystem;
extern std::mutex output_mutex;


// TupleHash Definition
struct TupleHash {
    template <typename T1, typename T2, typename T3>
    std::size_t operator()(const std::tuple<T1, T2, T3>& t) const {
        std::hash<T1> hash1;
        std::hash<T2> hash2;
        std::hash<T3> hash3;

        return hash1(std::get<0>(t)) ^ (hash2(std::get<1>(t)) << 1) ^ (hash3(std::get<2>(t)) << 2);
    }
};


// Structure to store solar radiation data
struct DataPoint {
    double time_difference;  // Time difference in minutes
    double value;            // Cumulative solar radiation
    double latitudepoint;    // Latitude
    double longitudepoint;   // Longitude
};

struct DataEntry {
    double value;
};


// Define Earth's area for the given points in square meters
struct PointData {
    double latitude;
    double longitude;
    double area_m2;
};

const vector<PointData> targetPoints = {
    {25, 45, 548215000000.0},   // 548,215 KM� -> m�
    {-25, 45, 571050000000.0},  // 571,050 KM� -> m�
    {40, -100, 455532000000.0}, // 455,532 KM� -> m�
    {-40, -100, 490232000000.0} // 490,232 KM� -> m�
};


// Function prototype (without default argument)
bool isClose(double a, double b, double tol);

// Function Declarations

//-------------- Radiation_Processing.cpp
double weight_function(int hour);
void process_radiation_data(const std::string& input_folder, const std::string& output_folder, const std::string& parameter, int year);

//-------------- Slot_Association.cpp
void get_cell_boundaries(double latitude, double longitude, int step,
    double& lat_start, double& lat_end,
    double& lon_start, double& lon_end);
void processFile(const std::string& inputFile, const std::string& outputFile);
void processDirectoryParallel(const std::string& inputDir, const std::string& outputDir, int threadCount);
void process_slot_association(const std::string& inputDir, const std::string& outputDir, int threadCount);

//-------------- Level.cpp
inline long double calcGPSDistance(long double latitude_new, long double longitude_new, long double latitude_old, long double longitude_old);
void process_level_area(const std::string&, const std::string&, const std::string&);

//-------------- Energy_based_on_solar_radiation.cpp
inline double calculate_declination_angle(int day_of_year);
inline double calculate_hour_angle(double local_time);
inline double calculate_zenith_angle(double latitude, double declination, double hour_angle);


void read_csv(const std::string& file_path,
    std::unordered_map<std::tuple<double, double, double>, DataEntry, TupleHash>& data_map,
    std::set<std::tuple<double, double, double>>& all_keys);

void process_data(
    const std::unordered_map<std::tuple<double, double, double>, DataEntry, TupleHash>& olr_data,
    const std::unordered_map<std::tuple<double, double, double>, DataEntry, TupleHash>& str_data,
    const std::unordered_map<std::tuple<double, double, double>, DataEntry, TupleHash>& ssrd_data,
    const std::unordered_map<std::tuple<double, double, double>, DataEntry, TupleHash>& tcc_data,
    const std::unordered_map<std::tuple<double, double, double>, DataEntry, TupleHash>& albedo_data,
    const std::set<std::tuple<double, double, double>>& all_keys,
    std::ofstream& out);
  

void process_energy_radiation(const std::string& input_folder, const std::string& output_folder, int year);

//-------------- Energy_based_on_temperature_capacity.cpp

double RHfromTd(double T, double Td);
std::map<std::tuple<double, double, double>, DataPoint> read_csv(const std::string& file_path);
std::map<std::pair<double, double>, double> read_area_data(const std::string& file_path);
double compute_heat_capacity(double temperature, double pressure, double humidity);
void calculate_energy(const std::map<std::tuple<double, double, double>, DataPoint>& temp_data,
    const std::map<std::tuple<double, double, double>, DataPoint>& dewpoint_data,
    const std::map<std::tuple<double, double, double>, DataPoint>& pressure_data,
    const std::map<std::pair<double, double>, double>& area_data,
    const std::string& output_file);

void process_energy_capacity(const std::string& input_folder, const std::string& output_folder, int year);


//-------------- Preparing_Display_Data.cpp
void processCSV(const string& inputFile);
void writeOutputCSV(const string& outputFile);
void preparing_display_data(const std::string& input_folder, const std::string& output_folder, int year);

#endif // HEADER_H
