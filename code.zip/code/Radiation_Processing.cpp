﻿/*
Processes radiation parameter files (OLR, STR, SSRD) downloaded from ERA5,
extracting and distributing aggregated data to cover all hours of the day.
*/
#include "header.h"

// Function: Weight Distribution for Energy
// Distributes energy based on time of day (morning/evening = lower, midday = higher)
double weight_function(int hour) {
    return exp(-pow((hour - PEAK_HOUR) / WIDTH, 2)); // Gaussian-like curve
}

// Function: Process Radiation Data from CSV 
void process_radiation_data(const std::string& input_file, const std::string& output_file, const std::string& parameter, int year) {
    std::cout << "Processing Radiation Data: " << input_file << std::endl;

    // Check if file exists before opening
    if (!std::filesystem::exists(input_file)) {
        std::cerr << "ERROR: File does NOT exist: " << input_file << std::endl;
        return;
    }

    std::ifstream file(input_file);
    if (!file.is_open()) {
        std::cerr << "ERROR: Could not open file: " << input_file << std::endl;
        return;
    }

    std::cout << "File successfully opened: " << input_file << std::endl;

    std::string line;
    std::map<std::pair<double, double>, std::map<int, double>> hourly_data; // Store per location & time
    std::map<int, double> previous_day_data; // Store last day's data for continuity

    // Skip header
    getline(file, line);

    // Track time range
    int min_time = std::numeric_limits<int>::max(), max_time = 0;

    // Read CSV Data
    while (getline(file, line)) {
        std::stringstream ss(line);
        std::string token;
        DataPoint dp;

        getline(ss, token, ','); dp.time_difference = stod(token);
        getline(ss, token, ','); dp.value = stod(token);
        getline(ss, token, ','); dp.latitudepoint = stod(token);
        getline(ss, token, ','); dp.longitudepoint = stod(token);

        int minute = static_cast<int>(dp.time_difference);
        min_time = std::min(min_time, minute);
        max_time = std::max(max_time, minute);

        if (minute < 0) {
            previous_day_data[minute] = dp.value;
        }
        else {
            hourly_data[{dp.latitudepoint, dp.longitudepoint}][minute] = dp.value;
        }
    }

    file.close();
    std::cout << "CSV file loaded successfully!" << std::endl;

    // Ensure proper processing range
    min_time = 0;
    max_time = MAX_TIME;

    // Open Output File
    std::ofstream out_file(output_file);
    if (!out_file.is_open()) {
        std::cerr << "ERROR: Could not create file: " << output_file << std::endl;
        return;
    }

    // Write headers
    out_file << "time_difference,value,latitudepoint,longitudepoint\n";

    // Process Data for All Hours
    for (const auto& entry : hourly_data) {
        double lat = entry.first.first;
        double lon = entry.first.second;
        const auto& values = entry.second;

        double prev_value = 0.0;
        int prev_minute = min_time;

        for (int minute = min_time; minute <= max_time; minute += MINUTES_IN_HOUR) {
            double hourly_value = 0.0;

            if (values.find(minute) != values.end()) {
                prev_value = values.at(minute);
                hourly_value = prev_value;
            }
            else {
                int hour = (minute / MINUTES_IN_HOUR) % HOURS_IN_DAY;
                double weight = weight_function(hour);

                if (!previous_day_data.empty()) {
                    hourly_value = previous_day_data.rbegin()->second * weight;
                }
                else {
                    hourly_value = prev_value * weight;
                }
            }

            // Ensure time starts from 0
            double time_diff = minute;

            out_file << std::fixed << std::setprecision(1) << time_diff << ","
                << std::fixed << std::setprecision(3) << hourly_value << ","
                << std::fixed << std::setprecision(2) << lat << ","
                << std::fixed << std::setprecision(2) << lon << "\n";

            prev_minute = minute;
        }
    }

    out_file.close();
    std::cout << "Processed CSV saved: " << output_file << std::endl;
}
